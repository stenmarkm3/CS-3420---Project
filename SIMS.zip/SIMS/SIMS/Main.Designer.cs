﻿namespace SIMS
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlStudentMain = new System.Windows.Forms.Panel();
            this.txtOverallGpa = new System.Windows.Forms.TextBox();
            this.txtSemester = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lstCourses = new System.Windows.Forms.ListBox();
            this.lblOverallGpa = new System.Windows.Forms.Label();
            this.lblSemester = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.pnlStudentCourse = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lstExamNamesAndGrades = new System.Windows.Forms.ListBox();
            this.pnlStudentMain.SuspendLayout();
            this.pnlStudentCourse.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlStudentMain
            // 
            this.pnlStudentMain.Controls.Add(this.txtOverallGpa);
            this.pnlStudentMain.Controls.Add(this.txtSemester);
            this.pnlStudentMain.Controls.Add(this.txtLastName);
            this.pnlStudentMain.Controls.Add(this.txtFirstName);
            this.pnlStudentMain.Controls.Add(this.lstCourses);
            this.pnlStudentMain.Controls.Add(this.lblOverallGpa);
            this.pnlStudentMain.Controls.Add(this.lblSemester);
            this.pnlStudentMain.Controls.Add(this.lblLastName);
            this.pnlStudentMain.Controls.Add(this.lblFirstName);
            this.pnlStudentMain.Controls.Add(this.pnlStudentCourse);
            this.pnlStudentMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlStudentMain.Location = new System.Drawing.Point(0, 0);
            this.pnlStudentMain.Name = "pnlStudentMain";
            this.pnlStudentMain.Size = new System.Drawing.Size(783, 527);
            this.pnlStudentMain.TabIndex = 0;
            // 
            // txtOverallGpa
            // 
            this.txtOverallGpa.Enabled = false;
            this.txtOverallGpa.Location = new System.Drawing.Point(125, 303);
            this.txtOverallGpa.Name = "txtOverallGpa";
            this.txtOverallGpa.Size = new System.Drawing.Size(183, 20);
            this.txtOverallGpa.TabIndex = 3;
            // 
            // txtSemester
            // 
            this.txtSemester.Enabled = false;
            this.txtSemester.Location = new System.Drawing.Point(125, 114);
            this.txtSemester.Name = "txtSemester";
            this.txtSemester.Size = new System.Drawing.Size(183, 20);
            this.txtSemester.TabIndex = 3;
            // 
            // txtLastName
            // 
            this.txtLastName.Enabled = false;
            this.txtLastName.Location = new System.Drawing.Point(125, 89);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(183, 20);
            this.txtLastName.TabIndex = 3;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Enabled = false;
            this.txtFirstName.Location = new System.Drawing.Point(125, 64);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(183, 20);
            this.txtFirstName.TabIndex = 3;
            // 
            // lstCourses
            // 
            this.lstCourses.FormattingEnabled = true;
            this.lstCourses.Location = new System.Drawing.Point(61, 153);
            this.lstCourses.Name = "lstCourses";
            this.lstCourses.Size = new System.Drawing.Size(247, 134);
            this.lstCourses.TabIndex = 2;
            // 
            // lblOverallGpa
            // 
            this.lblOverallGpa.AutoSize = true;
            this.lblOverallGpa.Location = new System.Drawing.Point(58, 306);
            this.lblOverallGpa.Name = "lblOverallGpa";
            this.lblOverallGpa.Size = new System.Drawing.Size(68, 13);
            this.lblOverallGpa.TabIndex = 1;
            this.lblOverallGpa.Text = "Overall GPA:";
            // 
            // lblSemester
            // 
            this.lblSemester.AutoSize = true;
            this.lblSemester.Location = new System.Drawing.Point(58, 117);
            this.lblSemester.Name = "lblSemester";
            this.lblSemester.Size = new System.Drawing.Size(54, 13);
            this.lblSemester.TabIndex = 1;
            this.lblSemester.Text = "Semester:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(58, 92);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(58, 64);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 1;
            this.lblFirstName.Text = "First Name:";
            // 
            // pnlStudentCourse
            // 
            this.pnlStudentCourse.Controls.Add(this.lstExamNamesAndGrades);
            this.pnlStudentCourse.Controls.Add(this.textBox3);
            this.pnlStudentCourse.Controls.Add(this.textBox2);
            this.pnlStudentCourse.Controls.Add(this.textBox1);
            this.pnlStudentCourse.Controls.Add(this.label3);
            this.pnlStudentCourse.Controls.Add(this.label2);
            this.pnlStudentCourse.Controls.Add(this.label1);
            this.pnlStudentCourse.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlStudentCourse.Location = new System.Drawing.Point(397, 0);
            this.pnlStudentCourse.Name = "pnlStudentCourse";
            this.pnlStudentCourse.Size = new System.Drawing.Size(386, 527);
            this.pnlStudentCourse.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Course:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Average:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "GPA:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(124, 64);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(124, 93);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(124, 126);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 1;
            // 
            // lstExamNamesAndGrades
            // 
            this.lstExamNamesAndGrades.FormattingEnabled = true;
            this.lstExamNamesAndGrades.Location = new System.Drawing.Point(62, 172);
            this.lstExamNamesAndGrades.Name = "lstExamNamesAndGrades";
            this.lstExamNamesAndGrades.Size = new System.Drawing.Size(220, 147);
            this.lstExamNamesAndGrades.TabIndex = 2;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(783, 527);
            this.Controls.Add(this.pnlStudentMain);
            this.MaximizeBox = false;
            this.Name = "Main";
            this.Text = "Student Information Management System";
            this.Load += new System.EventHandler(this.Main_Load);
            this.pnlStudentMain.ResumeLayout(false);
            this.pnlStudentMain.PerformLayout();
            this.pnlStudentCourse.ResumeLayout(false);
            this.pnlStudentCourse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlStudentMain;
        private System.Windows.Forms.Panel pnlStudentCourse;
        private System.Windows.Forms.TextBox txtOverallGpa;
        private System.Windows.Forms.TextBox txtSemester;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.ListBox lstCourses;
        private System.Windows.Forms.Label lblOverallGpa;
        private System.Windows.Forms.Label lblSemester;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.ListBox lstExamNamesAndGrades;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}