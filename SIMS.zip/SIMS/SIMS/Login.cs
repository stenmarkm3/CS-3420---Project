﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace SIMS
{
    public partial class Login : Form
    {
        SqlConnection con;
        string connectionString;

        public Login()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["SIMS.Properties.Settings.SIMSConnectionString"].ConnectionString;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string query = "SELECT userStatus FROM userMaster " +
                "WHERE userId = @userId AND userPasswd = @userPasswd";

            using (con = new SqlConnection(connectionString))
            using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
            {
                sda.SelectCommand.Parameters.AddWithValue("@userId", txtUserName.Text);
                sda.SelectCommand.Parameters.AddWithValue("@userPasswd", txtPassword.Text);
                DataTable dt = new System.Data.DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 1)
                {
                    this.Hide();
                    
                    Main ss = new Main(dt.Rows[0][0].ToString());
                    ss.Show();
                }
                else
                {
                    MessageBox.Show("Please Check your Username and Password");
                }
            }
            
        }

    }
}
