﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIMS
{
    public partial class Main : Form
    {
        public Main(string userStatus)
        {
            InitializeComponent();

            if (userStatus == "student")
            {
                pnlStudentMain.Visible = true;
                txtFirstName.Text = "Benjamin";
            }
            else if (userStatus == "admin")
            {
                pnlStudentMain.Visible = false;
            }
            else
            {
                MessageBox.Show("User Status Error");
                this.Close();
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
