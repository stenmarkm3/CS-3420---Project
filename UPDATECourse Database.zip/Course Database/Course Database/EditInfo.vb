﻿Public Class EditInfo
    Private SQL As New SQLControl



    Private Sub FetchUsers()
        lbUsers.Items.Clear()

        SQL.AddParams("@users", "%" & txtFilter.Text & "%")
        SQL.ExecQuery("SELECT userId " &
                      "FROM userMaster " &
                      "WHERE userId LIKE @users " &
                      "ORDER BY userId ASC;")

        If SQL.HasException(True) Then Exit Sub

        For Each r As DataRow In SQL.DBDT.Rows
            lbUsers.Items.Add(r("userId"))
        Next




    End Sub

    Private Sub EditInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SIMSDataSet.registeredCourses' table. You can move, or remove it, as needed.
        Me.RegisteredCoursesTableAdapter.Fill(Me.SIMSDataSet.registeredCourses)
        FetchUsers()
    End Sub

    Private Sub lbUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbUsers.SelectedIndexChanged

        GetUserDetails(lbUsers.Text)

    End Sub


    Private Sub txtFilter_KeyDown(sender As Object, e As KeyEventArgs) Handles txtFilter.KeyDown
        If e.KeyCode = Keys.Enter Then
            FetchUsers()
            e.Handled = True
            e.SuppressKeyPress = True
        End If

    End Sub

    Private Sub GetUserDetails(Username As String)
        SQL.AddParams("@user", Username)
        SQL.ExecQuery("SELECT * " &
                         "FROM userMaster " &
                         "WHERE userId = @user;")

        If SQL.RecordCount < 1 Then Exit Sub

        For Each r As DataRow In SQL.DBDT.Rows
            txtID.Text = r("userId")
            txtfName.Text = r("fName")
            txtlName.Text = r("lName")
        Next
    End Sub


    Private Sub UpdateUser()
        SQL.AddParams("@name", txtfName.Text)
        SQL.AddParams("@lName", txtlName.Text)
        SQL.AddParams("@id", txtID.Text)


        SQL.ExecQuery("UPDATE userMaster " &
                      "SET userId=@id, fName=@name, lName=@lName " &
                      "WHERE userId=@id;")

        If SQL.HasException(True) Then Exit Sub
        MsgBox("Update complete")

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        UpdateUser()
    End Sub

    Private Sub txtID_TextChanged(sender As Object, e As EventArgs) Handles txtID.TextChanged

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class