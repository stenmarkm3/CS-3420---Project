﻿Public Class ChildForm
    Public SQL As New SQLControl
    Public Sub LoadGrid()
        SQL.ExecQuery("SELECT * FROM exams;")
        If SQL.HasException(True) Then Exit Sub

        dgvData.DataSource = SQL.DBDT
    End Sub
    Private Sub ChildForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadGrid()

    End Sub

    Private Sub dgvData_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvData.CellContentClick

    End Sub
End Class