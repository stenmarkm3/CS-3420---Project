﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EditInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbUsers = New System.Windows.Forms.ListBox()
        Me.txtFilter = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.GroupBox()
        Me.txtlName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtfName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.SIMSDataSet = New Course_Database.SIMSDataSet()
        Me.RegisteredCoursesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegisteredCoursesTableAdapter = New Course_Database.SIMSDataSetTableAdapters.registeredCoursesTableAdapter()
        Me.RegisteredIdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SemesterDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StudentIdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CourseIdDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CourseAvgDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CourseGpaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnSave.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SIMSDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegisteredCoursesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbUsers
        '
        Me.lbUsers.FormattingEnabled = True
        Me.lbUsers.Location = New System.Drawing.Point(24, 70)
        Me.lbUsers.Name = "lbUsers"
        Me.lbUsers.Size = New System.Drawing.Size(170, 290)
        Me.lbUsers.TabIndex = 0
        '
        'txtFilter
        '
        Me.txtFilter.Location = New System.Drawing.Point(24, 44)
        Me.txtFilter.Name = "txtFilter"
        Me.txtFilter.Size = New System.Drawing.Size(170, 20)
        Me.txtFilter.TabIndex = 1
        '
        'btnSave
        '
        Me.btnSave.Controls.Add(Me.DataGridView1)
        Me.btnSave.Controls.Add(Me.txtlName)
        Me.btnSave.Controls.Add(Me.Label3)
        Me.btnSave.Controls.Add(Me.txtfName)
        Me.btnSave.Controls.Add(Me.Label2)
        Me.btnSave.Controls.Add(Me.Label1)
        Me.btnSave.Controls.Add(Me.txtID)
        Me.btnSave.Location = New System.Drawing.Point(242, 26)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(437, 339)
        Me.btnSave.TabIndex = 2
        Me.btnSave.TabStop = False
        Me.btnSave.Text = "Student Information"
        '
        'txtlName
        '
        Me.txtlName.BackColor = System.Drawing.SystemColors.Menu
        Me.txtlName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtlName.Location = New System.Drawing.Point(282, 31)
        Me.txtlName.Name = "txtlName"
        Me.txtlName.Size = New System.Drawing.Size(100, 13)
        Me.txtlName.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(28, 69)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Course:"
        '
        'txtfName
        '
        Me.txtfName.BackColor = System.Drawing.SystemColors.Menu
        Me.txtfName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtfName.Location = New System.Drawing.Point(210, 31)
        Me.txtfName.Name = "txtfName"
        Me.txtfName.ReadOnly = True
        Me.txtfName.Size = New System.Drawing.Size(66, 13)
        Me.txtfName.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(161, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "ID:"
        '
        'txtID
        '
        Me.txtID.BackColor = System.Drawing.SystemColors.Menu
        Me.txtID.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtID.Location = New System.Drawing.Point(55, 31)
        Me.txtID.Name = "txtID"
        Me.txtID.ReadOnly = True
        Me.txtID.Size = New System.Drawing.Size(100, 13)
        Me.txtID.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(354, 371)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(198, 62)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Save"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RegisteredIdDataGridViewTextBoxColumn, Me.SemesterDataGridViewTextBoxColumn, Me.StudentIdDataGridViewTextBoxColumn, Me.CourseIdDataGridViewTextBoxColumn, Me.CourseAvgDataGridViewTextBoxColumn, Me.CourseGpaDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.RegisteredCoursesBindingSource
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.DataGridView1.Location = New System.Drawing.Point(31, 85)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(400, 248)
        Me.DataGridView1.TabIndex = 9
        '
        'SIMSDataSet
        '
        Me.SIMSDataSet.DataSetName = "SIMSDataSet"
        Me.SIMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'RegisteredCoursesBindingSource
        '
        Me.RegisteredCoursesBindingSource.DataMember = "registeredCourses"
        Me.RegisteredCoursesBindingSource.DataSource = Me.SIMSDataSet
        '
        'RegisteredCoursesTableAdapter
        '
        Me.RegisteredCoursesTableAdapter.ClearBeforeFill = True
        '
        'RegisteredIdDataGridViewTextBoxColumn
        '
        Me.RegisteredIdDataGridViewTextBoxColumn.DataPropertyName = "registeredId"
        Me.RegisteredIdDataGridViewTextBoxColumn.HeaderText = "registeredId"
        Me.RegisteredIdDataGridViewTextBoxColumn.Name = "RegisteredIdDataGridViewTextBoxColumn"
        Me.RegisteredIdDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SemesterDataGridViewTextBoxColumn
        '
        Me.SemesterDataGridViewTextBoxColumn.DataPropertyName = "semester"
        Me.SemesterDataGridViewTextBoxColumn.HeaderText = "semester"
        Me.SemesterDataGridViewTextBoxColumn.Name = "SemesterDataGridViewTextBoxColumn"
        '
        'StudentIdDataGridViewTextBoxColumn
        '
        Me.StudentIdDataGridViewTextBoxColumn.DataPropertyName = "studentId"
        Me.StudentIdDataGridViewTextBoxColumn.HeaderText = "studentId"
        Me.StudentIdDataGridViewTextBoxColumn.Name = "StudentIdDataGridViewTextBoxColumn"
        '
        'CourseIdDataGridViewTextBoxColumn
        '
        Me.CourseIdDataGridViewTextBoxColumn.DataPropertyName = "courseId"
        Me.CourseIdDataGridViewTextBoxColumn.HeaderText = "courseId"
        Me.CourseIdDataGridViewTextBoxColumn.Name = "CourseIdDataGridViewTextBoxColumn"
        '
        'CourseAvgDataGridViewTextBoxColumn
        '
        Me.CourseAvgDataGridViewTextBoxColumn.DataPropertyName = "courseAvg"
        Me.CourseAvgDataGridViewTextBoxColumn.HeaderText = "courseAvg"
        Me.CourseAvgDataGridViewTextBoxColumn.Name = "CourseAvgDataGridViewTextBoxColumn"
        '
        'CourseGpaDataGridViewTextBoxColumn
        '
        Me.CourseGpaDataGridViewTextBoxColumn.DataPropertyName = "courseGpa"
        Me.CourseGpaDataGridViewTextBoxColumn.HeaderText = "courseGpa"
        Me.CourseGpaDataGridViewTextBoxColumn.Name = "CourseGpaDataGridViewTextBoxColumn"
        '
        'EditInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(693, 445)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtFilter)
        Me.Controls.Add(Me.lbUsers)
        Me.Name = "EditInfo"
        Me.Text = "Edit Information"
        Me.btnSave.ResumeLayout(False)
        Me.btnSave.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SIMSDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegisteredCoursesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbUsers As ListBox
    Friend WithEvents txtFilter As TextBox
    Friend WithEvents btnSave As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtfName As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents txtlName As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents SIMSDataSet As SIMSDataSet
    Friend WithEvents RegisteredCoursesBindingSource As BindingSource
    Friend WithEvents RegisteredCoursesTableAdapter As SIMSDataSetTableAdapters.registeredCoursesTableAdapter
    Friend WithEvents RegisteredIdDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SemesterDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StudentIdDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CourseIdDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CourseAvgDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CourseGpaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
