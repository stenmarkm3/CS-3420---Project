﻿Imports System.Data.SqlClient
Public Class Form1
    Private SQL As New SQLControl
    Private AuthUser As String


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If SQL.HasConnection = True Then
            ' MsgBox("Connection to server successfull.")
        End If


    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If SQL.HasConnection = True Then
            If IsAuthenticated() = True Then
                AuthUser = txtuserID.Text
                If AuthUser = "admin1" Then
                    EditInfo.Show()
                ElseIf AuthUser <> "admin1" Then
                    ChildForm.Show()
                End If
            End If
        End If
    End Sub

    Private Function IsAuthenticated() As Boolean
        If SQL.SQLDS IsNot Nothing Then
            SQL.SQLDS.Clear()
        End If

        SQL.RunQuery("SELECT Count(userId) As UserCount " &
                     "FROM userMaster " &
                     "WHERE userId='" & txtuserID.Text & "' " &
                     " AND userPasswd='" & txtuserPasswd.Text & "' COLLATE SQL_Latin1_General_CP1_CS_AS ")

        If SQL.SQLDS.Tables(0).Rows(0).Item("UserCount") = 1 Then
            Return True
        End If

        MsgBox("Invalid user credentials.", MsgBoxStyle.Critical, "Login failed")
        Return False



    End Function

    Private Sub txtuserID_TextChanged(sender As Object, e As EventArgs) Handles txtuserID.TextChanged
        Focus()
    End Sub
End Class
