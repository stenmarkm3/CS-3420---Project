﻿namespace SIMS
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msOptions = new System.Windows.Forms.MenuStrip();
            this.menuOptions = new System.Windows.Forms.ToolStripMenuItem();
            this.menuUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRegisteredCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.menuExams = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGpa = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlUsers = new System.Windows.Forms.Panel();
            this.btnUserDelete = new System.Windows.Forms.Button();
            this.btnUserSave = new System.Windows.Forms.Button();
            this.btnUserReset = new System.Windows.Forms.Button();
            this.btnUserSearch = new System.Windows.Forms.Button();
            this.cmbUserStatus = new System.Windows.Forms.ComboBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.lblUserStatus = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblUserId = new System.Windows.Forms.Label();
            this.dgvUsers = new System.Windows.Forms.DataGridView();
            this.pnlCourses = new System.Windows.Forms.Panel();
            this.btnCourseDelete = new System.Windows.Forms.Button();
            this.btnCourseSave = new System.Windows.Forms.Button();
            this.btnCourseReset = new System.Windows.Forms.Button();
            this.btnCourseSearch = new System.Windows.Forms.Button();
            this.txtCourseNumber = new System.Windows.Forms.TextBox();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblCourseNumber = new System.Windows.Forms.Label();
            this.dgvCourses = new System.Windows.Forms.DataGridView();
            this.msOptions.SuspendLayout();
            this.pnlUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.pnlCourses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourses)).BeginInit();
            this.SuspendLayout();
            // 
            // msOptions
            // 
            this.msOptions.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuOptions});
            this.msOptions.Location = new System.Drawing.Point(0, 0);
            this.msOptions.Name = "msOptions";
            this.msOptions.Size = new System.Drawing.Size(763, 24);
            this.msOptions.TabIndex = 0;
            this.msOptions.Text = "Options";
            // 
            // menuOptions
            // 
            this.menuOptions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuUsers,
            this.menuCourses,
            this.menuStudents});
            this.menuOptions.Name = "menuOptions";
            this.menuOptions.Size = new System.Drawing.Size(61, 20);
            this.menuOptions.Text = "Options";
            // 
            // menuUsers
            // 
            this.menuUsers.Name = "menuUsers";
            this.menuUsers.Size = new System.Drawing.Size(152, 22);
            this.menuUsers.Text = "Users";
            this.menuUsers.Click += new System.EventHandler(this.menuUsers_Click);
            // 
            // menuCourses
            // 
            this.menuCourses.Name = "menuCourses";
            this.menuCourses.Size = new System.Drawing.Size(152, 22);
            this.menuCourses.Text = "Courses";
            this.menuCourses.Click += new System.EventHandler(this.menuCourses_Click);
            // 
            // menuStudents
            // 
            this.menuStudents.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuRegisteredCourses,
            this.menuExams,
            this.menuGpa});
            this.menuStudents.Name = "menuStudents";
            this.menuStudents.Size = new System.Drawing.Size(152, 22);
            this.menuStudents.Text = "Students";
            // 
            // menuRegisteredCourses
            // 
            this.menuRegisteredCourses.Name = "menuRegisteredCourses";
            this.menuRegisteredCourses.Size = new System.Drawing.Size(174, 22);
            this.menuRegisteredCourses.Text = "Registered Courses";
            // 
            // menuExams
            // 
            this.menuExams.Name = "menuExams";
            this.menuExams.Size = new System.Drawing.Size(174, 22);
            this.menuExams.Text = "Exams";
            // 
            // menuGpa
            // 
            this.menuGpa.Name = "menuGpa";
            this.menuGpa.Size = new System.Drawing.Size(174, 22);
            this.menuGpa.Text = "GPA";
            // 
            // pnlUsers
            // 
            this.pnlUsers.Controls.Add(this.btnUserDelete);
            this.pnlUsers.Controls.Add(this.btnUserSave);
            this.pnlUsers.Controls.Add(this.btnUserReset);
            this.pnlUsers.Controls.Add(this.btnUserSearch);
            this.pnlUsers.Controls.Add(this.cmbUserStatus);
            this.pnlUsers.Controls.Add(this.txtLastName);
            this.pnlUsers.Controls.Add(this.txtFirstName);
            this.pnlUsers.Controls.Add(this.txtPassword);
            this.pnlUsers.Controls.Add(this.txtUserId);
            this.pnlUsers.Controls.Add(this.lblUserStatus);
            this.pnlUsers.Controls.Add(this.lblPassword);
            this.pnlUsers.Controls.Add(this.lblLastName);
            this.pnlUsers.Controls.Add(this.lblFirstName);
            this.pnlUsers.Controls.Add(this.lblUserId);
            this.pnlUsers.Controls.Add(this.dgvUsers);
            this.pnlUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUsers.Location = new System.Drawing.Point(0, 24);
            this.pnlUsers.Name = "pnlUsers";
            this.pnlUsers.Size = new System.Drawing.Size(763, 436);
            this.pnlUsers.TabIndex = 1;
            // 
            // btnUserDelete
            // 
            this.btnUserDelete.Location = new System.Drawing.Point(153, 321);
            this.btnUserDelete.Name = "btnUserDelete";
            this.btnUserDelete.Size = new System.Drawing.Size(106, 33);
            this.btnUserDelete.TabIndex = 14;
            this.btnUserDelete.Text = "Delete";
            this.btnUserDelete.UseVisualStyleBackColor = true;
            this.btnUserDelete.Click += new System.EventHandler(this.btnUserDelete_Click);
            // 
            // btnUserSave
            // 
            this.btnUserSave.Location = new System.Drawing.Point(153, 279);
            this.btnUserSave.Name = "btnUserSave";
            this.btnUserSave.Size = new System.Drawing.Size(106, 33);
            this.btnUserSave.TabIndex = 13;
            this.btnUserSave.Text = "Save";
            this.btnUserSave.UseVisualStyleBackColor = true;
            this.btnUserSave.Click += new System.EventHandler(this.btnUserSave_Click);
            // 
            // btnUserReset
            // 
            this.btnUserReset.Location = new System.Drawing.Point(35, 321);
            this.btnUserReset.Name = "btnUserReset";
            this.btnUserReset.Size = new System.Drawing.Size(106, 33);
            this.btnUserReset.TabIndex = 12;
            this.btnUserReset.Text = "Reset";
            this.btnUserReset.UseVisualStyleBackColor = true;
            this.btnUserReset.Click += new System.EventHandler(this.btnUserReset_Click);
            // 
            // btnUserSearch
            // 
            this.btnUserSearch.Location = new System.Drawing.Point(35, 279);
            this.btnUserSearch.Name = "btnUserSearch";
            this.btnUserSearch.Size = new System.Drawing.Size(106, 33);
            this.btnUserSearch.TabIndex = 11;
            this.btnUserSearch.Text = "Search";
            this.btnUserSearch.UseVisualStyleBackColor = true;
            this.btnUserSearch.Click += new System.EventHandler(this.btnUserSearch_Click);
            // 
            // cmbUserStatus
            // 
            this.cmbUserStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserStatus.FormattingEnabled = true;
            this.cmbUserStatus.Location = new System.Drawing.Point(110, 180);
            this.cmbUserStatus.Name = "cmbUserStatus";
            this.cmbUserStatus.Size = new System.Drawing.Size(143, 21);
            this.cmbUserStatus.TabIndex = 10;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(110, 154);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(143, 20);
            this.txtLastName.TabIndex = 9;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(110, 128);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(143, 20);
            this.txtFirstName.TabIndex = 8;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(110, 102);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(143, 20);
            this.txtPassword.TabIndex = 7;
            // 
            // txtUserId
            // 
            this.txtUserId.Location = new System.Drawing.Point(110, 75);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(143, 20);
            this.txtUserId.TabIndex = 6;
            // 
            // lblUserStatus
            // 
            this.lblUserStatus.AutoSize = true;
            this.lblUserStatus.Location = new System.Drawing.Point(42, 182);
            this.lblUserStatus.Name = "lblUserStatus";
            this.lblUserStatus.Size = new System.Drawing.Size(62, 13);
            this.lblUserStatus.TabIndex = 5;
            this.lblUserStatus.Text = "User Status";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(48, 102);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(56, 13);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(43, 156);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 3;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(44, 129);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 2;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblUserId
            // 
            this.lblUserId.AutoSize = true;
            this.lblUserId.Location = new System.Drawing.Point(58, 77);
            this.lblUserId.Name = "lblUserId";
            this.lblUserId.Size = new System.Drawing.Size(46, 13);
            this.lblUserId.TabIndex = 1;
            this.lblUserId.Text = "User ID:";
            // 
            // dgvUsers
            // 
            this.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvUsers.Location = new System.Drawing.Point(300, 0);
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.ReadOnly = true;
            this.dgvUsers.Size = new System.Drawing.Size(463, 436);
            this.dgvUsers.TabIndex = 0;
            this.dgvUsers.DoubleClick += new System.EventHandler(this.dgvUsers_DoubleClick);
            // 
            // pnlCourses
            // 
            this.pnlCourses.Controls.Add(this.dgvCourses);
            this.pnlCourses.Controls.Add(this.btnCourseDelete);
            this.pnlCourses.Controls.Add(this.btnCourseSave);
            this.pnlCourses.Controls.Add(this.btnCourseReset);
            this.pnlCourses.Controls.Add(this.btnCourseSearch);
            this.pnlCourses.Controls.Add(this.txtCourseNumber);
            this.pnlCourses.Controls.Add(this.txtDepartment);
            this.pnlCourses.Controls.Add(this.lblDepartment);
            this.pnlCourses.Controls.Add(this.lblCourseNumber);
            this.pnlCourses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCourses.Location = new System.Drawing.Point(0, 24);
            this.pnlCourses.Name = "pnlCourses";
            this.pnlCourses.Size = new System.Drawing.Size(763, 436);
            this.pnlCourses.TabIndex = 2;
            // 
            // btnCourseDelete
            // 
            this.btnCourseDelete.Location = new System.Drawing.Point(153, 320);
            this.btnCourseDelete.Name = "btnCourseDelete";
            this.btnCourseDelete.Size = new System.Drawing.Size(106, 33);
            this.btnCourseDelete.TabIndex = 28;
            this.btnCourseDelete.Text = "Delete";
            this.btnCourseDelete.UseVisualStyleBackColor = true;
            this.btnCourseDelete.Click += new System.EventHandler(this.btnCourseDelete_Click);
            // 
            // btnCourseSave
            // 
            this.btnCourseSave.Location = new System.Drawing.Point(153, 278);
            this.btnCourseSave.Name = "btnCourseSave";
            this.btnCourseSave.Size = new System.Drawing.Size(106, 33);
            this.btnCourseSave.TabIndex = 27;
            this.btnCourseSave.Text = "Save";
            this.btnCourseSave.UseVisualStyleBackColor = true;
            this.btnCourseSave.Click += new System.EventHandler(this.btnCourseSave_Click);
            // 
            // btnCourseReset
            // 
            this.btnCourseReset.Location = new System.Drawing.Point(35, 320);
            this.btnCourseReset.Name = "btnCourseReset";
            this.btnCourseReset.Size = new System.Drawing.Size(106, 33);
            this.btnCourseReset.TabIndex = 26;
            this.btnCourseReset.Text = "Reset";
            this.btnCourseReset.UseVisualStyleBackColor = true;
            this.btnCourseReset.Click += new System.EventHandler(this.btnCourseReset_Click);
            // 
            // btnCourseSearch
            // 
            this.btnCourseSearch.Location = new System.Drawing.Point(35, 278);
            this.btnCourseSearch.Name = "btnCourseSearch";
            this.btnCourseSearch.Size = new System.Drawing.Size(106, 33);
            this.btnCourseSearch.TabIndex = 25;
            this.btnCourseSearch.Text = "Search";
            this.btnCourseSearch.UseVisualStyleBackColor = true;
            this.btnCourseSearch.Click += new System.EventHandler(this.btnCourseSearch_Click);
            // 
            // txtCourseNumber
            // 
            this.txtCourseNumber.Location = new System.Drawing.Point(110, 127);
            this.txtCourseNumber.Name = "txtCourseNumber";
            this.txtCourseNumber.Size = new System.Drawing.Size(143, 20);
            this.txtCourseNumber.TabIndex = 22;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(110, 101);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(143, 20);
            this.txtDepartment.TabIndex = 21;
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Location = new System.Drawing.Point(40, 101);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(65, 13);
            this.lblDepartment.TabIndex = 18;
            this.lblDepartment.Text = "Department:";
            // 
            // lblCourseNumber
            // 
            this.lblCourseNumber.AutoSize = true;
            this.lblCourseNumber.Location = new System.Drawing.Point(21, 128);
            this.lblCourseNumber.Name = "lblCourseNumber";
            this.lblCourseNumber.Size = new System.Drawing.Size(83, 13);
            this.lblCourseNumber.TabIndex = 16;
            this.lblCourseNumber.Text = "Course Number:";
            // 
            // dgvCourses
            // 
            this.dgvCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCourses.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvCourses.Location = new System.Drawing.Point(300, 0);
            this.dgvCourses.Name = "dgvCourses";
            this.dgvCourses.Size = new System.Drawing.Size(463, 436);
            this.dgvCourses.TabIndex = 29;
            this.dgvCourses.DoubleClick += new System.EventHandler(this.dgvCourses_DoubleClick);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 460);
            this.Controls.Add(this.pnlCourses);
            this.Controls.Add(this.pnlUsers);
            this.Controls.Add(this.msOptions);
            this.MainMenuStrip = this.msOptions;
            this.Name = "Admin";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Admin_Load);
            this.msOptions.ResumeLayout(false);
            this.msOptions.PerformLayout();
            this.pnlUsers.ResumeLayout(false);
            this.pnlUsers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.pnlCourses.ResumeLayout(false);
            this.pnlCourses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msOptions;
        private System.Windows.Forms.ToolStripMenuItem menuOptions;
        private System.Windows.Forms.ToolStripMenuItem menuUsers;
        private System.Windows.Forms.ToolStripMenuItem menuCourses;
        private System.Windows.Forms.ToolStripMenuItem menuStudents;
        private System.Windows.Forms.ToolStripMenuItem menuRegisteredCourses;
        private System.Windows.Forms.ToolStripMenuItem menuExams;
        private System.Windows.Forms.ToolStripMenuItem menuGpa;
        private System.Windows.Forms.Panel pnlUsers;
        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.Button btnUserDelete;
        private System.Windows.Forms.Button btnUserSave;
        private System.Windows.Forms.Button btnUserReset;
        private System.Windows.Forms.Button btnUserSearch;
        private System.Windows.Forms.ComboBox cmbUserStatus;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Label lblUserStatus;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblUserId;
        private System.Windows.Forms.Panel pnlCourses;
        private System.Windows.Forms.DataGridView dgvCourses;
        private System.Windows.Forms.Button btnCourseDelete;
        private System.Windows.Forms.Button btnCourseSave;
        private System.Windows.Forms.Button btnCourseReset;
        private System.Windows.Forms.Button btnCourseSearch;
        private System.Windows.Forms.TextBox txtCourseNumber;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Label lblCourseNumber;
    }
}