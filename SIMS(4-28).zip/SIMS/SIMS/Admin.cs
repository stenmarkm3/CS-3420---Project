﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace SIMS
{
    public partial class Admin : Form
    {
        SqlConnection con;
        string connectionString;
        int courseId = 0;

        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sIMSDataSet.userMaster' table. You can move, or remove it, as needed.
            pnlCourses.Visible = false;
            //pnlExams.Visible = false;
            //pnlGpa.Visible = false;
            //pnlRegCourses.Visible = false;
            pnlUsers.Visible = false;
            connectionString = ConfigurationManager.ConnectionStrings["SIMS.Properties.Settings.SIMSConnectionString"].ConnectionString;
            con = new SqlConnection(connectionString);
        }

        private void menuUsers_Click(object sender, EventArgs e)
        {
            pnlCourses.Visible = false;
            //pnlExams.Visible = false;
            //pnlGpa.Visible = false;
            //pnlRegCourses.Visible = false;
            pnlUsers.Visible = true;

            UserReset();

        }


        private void btnUserSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                if (btnUserSave.Text == "Add")
                {
                    SqlCommand cmd = new SqlCommand("UserAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Add");
                    cmd.Parameters.AddWithValue("@userId", txtUserId.Text.Trim());
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
                    cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                    cmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                    cmd.Parameters.AddWithValue("@status", cmbUserStatus.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User added successfully");
                    UserReset();
                    FillUserDataGridView();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UserAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Edit");
                    cmd.Parameters.AddWithValue("@userId", txtUserId.Text);
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
                    cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                    cmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                    cmd.Parameters.AddWithValue("@status", cmbUserStatus.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User updated successfully");
                    UserReset();
                    FillUserDataGridView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
            
        }

        void FillUserDataGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("UserSearch", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.Parameters.AddWithValue("@userId", txtUserId.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@status", cmbUserStatus.Text);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvUsers.DataSource = dt;
            con.Close();
        }

        private void btnUserReset_Click(object sender, EventArgs e)
        {
            UserReset();
        }

        void UserReset()
        {
            txtFirstName.Text = txtLastName.Text = txtPassword.Text = txtUserId.Text = "";
            cmbUserStatus.SelectedIndex = -1;
            btnUserSave.Text = "Add";
            btnUserDelete.Enabled = false;
        }

        private void btnUserSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillUserDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dgvUsers_DoubleClick(object sender, EventArgs e)
        {
            if (dgvUsers.CurrentRow.Index != -1)
            {
                txtUserId.Text = dgvUsers.CurrentRow.Cells[0].Value.ToString();
                txtPassword.Text = dgvUsers.CurrentRow.Cells[1].Value.ToString();
                txtFirstName.Text = dgvUsers.CurrentRow.Cells[2].Value.ToString();
                txtLastName.Text = dgvUsers.CurrentRow.Cells[3].Value.ToString();
                cmbUserStatus.Text = dgvUsers.CurrentRow.Cells[4].Value.ToString();

                btnUserSave.Text = "Update";
                btnUserDelete.Enabled = true;
                txtUserId.Enabled = false;
            }
        }

        private void btnUserDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                
                SqlCommand cmd = new SqlCommand("UserDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userId", txtUserId.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User deleted successfully");
                UserReset();
                FillUserDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        private void menuCourses_Click(object sender, EventArgs e)
        {
            pnlCourses.Visible = true;
            //pnlExams.Visible = false;
            //pnlGpa.Visible = false;
            //pnlRegCourses.Visible = false;
            pnlUsers.Visible = false;

            CourseReset();
        }

        private void btnCourseSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                if (btnUserSave.Text == "Add")
                {
                    SqlCommand cmd = new SqlCommand("CourseAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Add");
                    cmd.Parameters.AddWithValue("@courseId", 0);
                    cmd.Parameters.AddWithValue("@department", txtDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", txtCourseNumber.Text.Trim());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course added successfully");
                    CourseReset();
                    FillCoursesDataGridView();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("CourseAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Edit");
                    cmd.Parameters.AddWithValue("@courseId", courseId);
                    cmd.Parameters.AddWithValue("@department", txtDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", txtCourseNumber.Text.Trim());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course updated successfully");
                    CourseReset();
                    FillCoursesDataGridView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        void FillCoursesDataGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("CourseSearch", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.Parameters.AddWithValue("@department", txtDepartment.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@courseNumber", txtCourseNumber.Text.Trim());
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvCourses.DataSource = dt;
            dgvCourses.Columns[0].Visible = false;
            con.Close();
        }

        private void btnCourseReset_Click(object sender, EventArgs e)
        {
            CourseReset();
        }

        void CourseReset()
        {
            txtDepartment.Text = txtCourseNumber.Text = "";
            btnCourseSave.Text = "Add";
            courseId = 0;
            btnCourseDelete.Enabled = false;
        }

        private void btnCourseSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillCoursesDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }

        }

        private void dgvCourses_DoubleClick(object sender, EventArgs e)
        {
            if (dgvCourses.CurrentRow.Index != -1)
            {
                courseId = Convert.ToInt32(dgvCourses.CurrentRow.Cells[0].Value.ToString());
                txtDepartment.Text = dgvCourses.CurrentRow.Cells[1].Value.ToString();
                txtCourseNumber.Text = dgvCourses.CurrentRow.Cells[2].Value.ToString();

                btnCourseSave.Text = "Update";
                btnCourseDelete.Enabled = true;
            }
        }

        private void btnCourseDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlCommand cmd = new SqlCommand("CourseDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@courseId", courseId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Course deleted successfully");
                CourseReset();
                FillCoursesDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }
    }
}
