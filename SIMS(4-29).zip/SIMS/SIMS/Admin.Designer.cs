﻿namespace SIMS
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msOptions = new System.Windows.Forms.MenuStrip();
            this.menuOptions = new System.Windows.Forms.ToolStripMenuItem();
            this.menuUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStudents = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRegisteredCourses = new System.Windows.Forms.ToolStripMenuItem();
            this.menuExams = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGpa = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlUsers = new System.Windows.Forms.Panel();
            this.btnUserDelete = new System.Windows.Forms.Button();
            this.btnUserSave = new System.Windows.Forms.Button();
            this.btnUserReset = new System.Windows.Forms.Button();
            this.btnUserSearch = new System.Windows.Forms.Button();
            this.cmbUserStatus = new System.Windows.Forms.ComboBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.lblUserStatus = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblUserId = new System.Windows.Forms.Label();
            this.dgvUsers = new System.Windows.Forms.DataGridView();
            this.pnlCourses = new System.Windows.Forms.Panel();
            this.dgvCourses = new System.Windows.Forms.DataGridView();
            this.btnCourseDelete = new System.Windows.Forms.Button();
            this.btnCourseSave = new System.Windows.Forms.Button();
            this.btnCourseReset = new System.Windows.Forms.Button();
            this.btnCourseSearch = new System.Windows.Forms.Button();
            this.txtCourseNumber = new System.Windows.Forms.TextBox();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.lblCourseNumber = new System.Windows.Forms.Label();
            this.pnlRegisteredCourses = new System.Windows.Forms.Panel();
            this.dgvRegCourses = new System.Windows.Forms.DataGridView();
            this.lstRegCourses = new System.Windows.Forms.ListBox();
            this.btnRegDelete = new System.Windows.Forms.Button();
            this.btnRegSave = new System.Windows.Forms.Button();
            this.btnRegReset = new System.Windows.Forms.Button();
            this.btnRegSearch = new System.Windows.Forms.Button();
            this.txtRegCourseNumber = new System.Windows.Forms.TextBox();
            this.txtRegSemester = new System.Windows.Forms.TextBox();
            this.txtRegFirstName = new System.Windows.Forms.TextBox();
            this.txtRegDepartment = new System.Windows.Forms.TextBox();
            this.lblRegDepartment = new System.Windows.Forms.Label();
            this.txtRegLastName = new System.Windows.Forms.TextBox();
            this.lblRegLastName = new System.Windows.Forms.Label();
            this.lblRegCourseNumber = new System.Windows.Forms.Label();
            this.txtRegStudentId = new System.Windows.Forms.TextBox();
            this.lblRegSemester = new System.Windows.Forms.Label();
            this.lblRegStudentId = new System.Windows.Forms.Label();
            this.lblRegFirstName = new System.Windows.Forms.Label();
            this.pnlExams = new System.Windows.Forms.Panel();
            this.dgvExam = new System.Windows.Forms.DataGridView();
            this.lstExam = new System.Windows.Forms.ListBox();
            this.btnExamDelete = new System.Windows.Forms.Button();
            this.btnExamSave = new System.Windows.Forms.Button();
            this.btnExamReset = new System.Windows.Forms.Button();
            this.btnExamSearch = new System.Windows.Forms.Button();
            this.txtExamName = new System.Windows.Forms.TextBox();
            this.txtExamCourseNumber = new System.Windows.Forms.TextBox();
            this.txtExamDepartment = new System.Windows.Forms.TextBox();
            this.txtExamFirstName = new System.Windows.Forms.TextBox();
            this.txtExamGrade = new System.Windows.Forms.TextBox();
            this.lblExamGrade = new System.Windows.Forms.Label();
            this.txtExamLastName = new System.Windows.Forms.TextBox();
            this.lblExamLastName = new System.Windows.Forms.Label();
            this.txtExamSemester = new System.Windows.Forms.TextBox();
            this.txtExamStudentId = new System.Windows.Forms.TextBox();
            this.lblExamSemester = new System.Windows.Forms.Label();
            this.lblExamCourseNumber = new System.Windows.Forms.Label();
            this.lblExamName = new System.Windows.Forms.Label();
            this.lblExamDepartment = new System.Windows.Forms.Label();
            this.lblExamStudentId = new System.Windows.Forms.Label();
            this.lblExamFirstName = new System.Windows.Forms.Label();
            this.pnlGpa = new System.Windows.Forms.Panel();
            this.btnGpaReset = new System.Windows.Forms.Button();
            this.btnGpaSearch = new System.Windows.Forms.Button();
            this.txtGpaOverall = new System.Windows.Forms.TextBox();
            this.txtGpaSemester = new System.Windows.Forms.TextBox();
            this.txtGpaLastName = new System.Windows.Forms.TextBox();
            this.txtGpaStudentId = new System.Windows.Forms.TextBox();
            this.txtGpaFirstName = new System.Windows.Forms.TextBox();
            this.lstGpaCourses = new System.Windows.Forms.ListBox();
            this.lblOverallGpa = new System.Windows.Forms.Label();
            this.lblSemester = new System.Windows.Forms.Label();
            this.lblGpaStudentId = new System.Windows.Forms.Label();
            this.lblGpaLastName = new System.Windows.Forms.Label();
            this.lblGpaFirstName = new System.Windows.Forms.Label();
            this.pnlGpaCourseGrades = new System.Windows.Forms.Panel();
            this.dgvGpa = new System.Windows.Forms.DataGridView();
            this.lstGpaExamNamesAndGrades = new System.Windows.Forms.ListBox();
            this.txtGpa = new System.Windows.Forms.TextBox();
            this.txtGpaAverage = new System.Windows.Forms.TextBox();
            this.txtGpaCourse = new System.Windows.Forms.TextBox();
            this.lblGpa = new System.Windows.Forms.Label();
            this.lblGpaAverage = new System.Windows.Forms.Label();
            this.lblGpaCourse = new System.Windows.Forms.Label();
            this.msOptions.SuspendLayout();
            this.pnlUsers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).BeginInit();
            this.pnlCourses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourses)).BeginInit();
            this.pnlRegisteredCourses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegCourses)).BeginInit();
            this.pnlExams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExam)).BeginInit();
            this.pnlGpa.SuspendLayout();
            this.pnlGpaCourseGrades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGpa)).BeginInit();
            this.SuspendLayout();
            // 
            // msOptions
            // 
            this.msOptions.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuOptions});
            this.msOptions.Location = new System.Drawing.Point(0, 0);
            this.msOptions.Name = "msOptions";
            this.msOptions.Size = new System.Drawing.Size(763, 24);
            this.msOptions.TabIndex = 0;
            this.msOptions.Text = "Options";
            // 
            // menuOptions
            // 
            this.menuOptions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuUsers,
            this.menuCourses,
            this.menuStudents});
            this.menuOptions.Name = "menuOptions";
            this.menuOptions.Size = new System.Drawing.Size(61, 20);
            this.menuOptions.Text = "Options";
            // 
            // menuUsers
            // 
            this.menuUsers.Name = "menuUsers";
            this.menuUsers.Size = new System.Drawing.Size(120, 22);
            this.menuUsers.Text = "Users";
            this.menuUsers.Click += new System.EventHandler(this.menuUsers_Click);
            // 
            // menuCourses
            // 
            this.menuCourses.Name = "menuCourses";
            this.menuCourses.Size = new System.Drawing.Size(120, 22);
            this.menuCourses.Text = "Courses";
            this.menuCourses.Click += new System.EventHandler(this.menuCourses_Click);
            // 
            // menuStudents
            // 
            this.menuStudents.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuRegisteredCourses,
            this.menuExams,
            this.menuGpa});
            this.menuStudents.Name = "menuStudents";
            this.menuStudents.Size = new System.Drawing.Size(120, 22);
            this.menuStudents.Text = "Students";
            // 
            // menuRegisteredCourses
            // 
            this.menuRegisteredCourses.Name = "menuRegisteredCourses";
            this.menuRegisteredCourses.Size = new System.Drawing.Size(174, 22);
            this.menuRegisteredCourses.Text = "Registered Courses";
            this.menuRegisteredCourses.Click += new System.EventHandler(this.menuRegisteredCourses_Click);
            // 
            // menuExams
            // 
            this.menuExams.Name = "menuExams";
            this.menuExams.Size = new System.Drawing.Size(174, 22);
            this.menuExams.Text = "Exams";
            this.menuExams.Click += new System.EventHandler(this.menuExams_Click);
            // 
            // menuGpa
            // 
            this.menuGpa.Name = "menuGpa";
            this.menuGpa.Size = new System.Drawing.Size(174, 22);
            this.menuGpa.Text = "GPA";
            this.menuGpa.Click += new System.EventHandler(this.menuGpa_Click);
            // 
            // pnlUsers
            // 
            this.pnlUsers.Controls.Add(this.btnUserDelete);
            this.pnlUsers.Controls.Add(this.btnUserSave);
            this.pnlUsers.Controls.Add(this.btnUserReset);
            this.pnlUsers.Controls.Add(this.btnUserSearch);
            this.pnlUsers.Controls.Add(this.cmbUserStatus);
            this.pnlUsers.Controls.Add(this.txtLastName);
            this.pnlUsers.Controls.Add(this.txtFirstName);
            this.pnlUsers.Controls.Add(this.txtPassword);
            this.pnlUsers.Controls.Add(this.txtUserId);
            this.pnlUsers.Controls.Add(this.lblUserStatus);
            this.pnlUsers.Controls.Add(this.lblPassword);
            this.pnlUsers.Controls.Add(this.lblLastName);
            this.pnlUsers.Controls.Add(this.lblFirstName);
            this.pnlUsers.Controls.Add(this.lblUserId);
            this.pnlUsers.Controls.Add(this.dgvUsers);
            this.pnlUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUsers.Location = new System.Drawing.Point(0, 24);
            this.pnlUsers.Name = "pnlUsers";
            this.pnlUsers.Size = new System.Drawing.Size(763, 436);
            this.pnlUsers.TabIndex = 1;
            // 
            // btnUserDelete
            // 
            this.btnUserDelete.Location = new System.Drawing.Point(153, 321);
            this.btnUserDelete.Name = "btnUserDelete";
            this.btnUserDelete.Size = new System.Drawing.Size(106, 33);
            this.btnUserDelete.TabIndex = 14;
            this.btnUserDelete.Text = "Delete";
            this.btnUserDelete.UseVisualStyleBackColor = true;
            this.btnUserDelete.Click += new System.EventHandler(this.btnUserDelete_Click);
            // 
            // btnUserSave
            // 
            this.btnUserSave.Location = new System.Drawing.Point(153, 279);
            this.btnUserSave.Name = "btnUserSave";
            this.btnUserSave.Size = new System.Drawing.Size(106, 33);
            this.btnUserSave.TabIndex = 13;
            this.btnUserSave.Text = "Save";
            this.btnUserSave.UseVisualStyleBackColor = true;
            this.btnUserSave.Click += new System.EventHandler(this.btnUserSave_Click);
            // 
            // btnUserReset
            // 
            this.btnUserReset.Location = new System.Drawing.Point(35, 321);
            this.btnUserReset.Name = "btnUserReset";
            this.btnUserReset.Size = new System.Drawing.Size(106, 33);
            this.btnUserReset.TabIndex = 12;
            this.btnUserReset.Text = "Reset";
            this.btnUserReset.UseVisualStyleBackColor = true;
            this.btnUserReset.Click += new System.EventHandler(this.btnUserReset_Click);
            // 
            // btnUserSearch
            // 
            this.btnUserSearch.Location = new System.Drawing.Point(35, 279);
            this.btnUserSearch.Name = "btnUserSearch";
            this.btnUserSearch.Size = new System.Drawing.Size(106, 33);
            this.btnUserSearch.TabIndex = 11;
            this.btnUserSearch.Text = "Search";
            this.btnUserSearch.UseVisualStyleBackColor = true;
            this.btnUserSearch.Click += new System.EventHandler(this.btnUserSearch_Click);
            // 
            // cmbUserStatus
            // 
            this.cmbUserStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserStatus.FormattingEnabled = true;
            this.cmbUserStatus.Location = new System.Drawing.Point(110, 180);
            this.cmbUserStatus.Name = "cmbUserStatus";
            this.cmbUserStatus.Size = new System.Drawing.Size(143, 21);
            this.cmbUserStatus.TabIndex = 10;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(110, 154);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(143, 20);
            this.txtLastName.TabIndex = 9;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(110, 128);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(143, 20);
            this.txtFirstName.TabIndex = 8;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(110, 102);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(143, 20);
            this.txtPassword.TabIndex = 7;
            // 
            // txtUserId
            // 
            this.txtUserId.Location = new System.Drawing.Point(110, 75);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(143, 20);
            this.txtUserId.TabIndex = 6;
            // 
            // lblUserStatus
            // 
            this.lblUserStatus.AutoSize = true;
            this.lblUserStatus.Location = new System.Drawing.Point(42, 182);
            this.lblUserStatus.Name = "lblUserStatus";
            this.lblUserStatus.Size = new System.Drawing.Size(62, 13);
            this.lblUserStatus.TabIndex = 5;
            this.lblUserStatus.Text = "User Status";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(48, 102);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(56, 13);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(43, 156);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 3;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(44, 129);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 2;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblUserId
            // 
            this.lblUserId.AutoSize = true;
            this.lblUserId.Location = new System.Drawing.Point(58, 77);
            this.lblUserId.Name = "lblUserId";
            this.lblUserId.Size = new System.Drawing.Size(46, 13);
            this.lblUserId.TabIndex = 1;
            this.lblUserId.Text = "User ID:";
            // 
            // dgvUsers
            // 
            this.dgvUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsers.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvUsers.Location = new System.Drawing.Point(300, 0);
            this.dgvUsers.Name = "dgvUsers";
            this.dgvUsers.ReadOnly = true;
            this.dgvUsers.Size = new System.Drawing.Size(463, 436);
            this.dgvUsers.TabIndex = 0;
            this.dgvUsers.DoubleClick += new System.EventHandler(this.dgvUsers_DoubleClick);
            // 
            // pnlCourses
            // 
            this.pnlCourses.Controls.Add(this.dgvCourses);
            this.pnlCourses.Controls.Add(this.btnCourseDelete);
            this.pnlCourses.Controls.Add(this.btnCourseSave);
            this.pnlCourses.Controls.Add(this.btnCourseReset);
            this.pnlCourses.Controls.Add(this.btnCourseSearch);
            this.pnlCourses.Controls.Add(this.txtCourseNumber);
            this.pnlCourses.Controls.Add(this.txtDepartment);
            this.pnlCourses.Controls.Add(this.lblDepartment);
            this.pnlCourses.Controls.Add(this.lblCourseNumber);
            this.pnlCourses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCourses.Location = new System.Drawing.Point(0, 24);
            this.pnlCourses.Name = "pnlCourses";
            this.pnlCourses.Size = new System.Drawing.Size(763, 436);
            this.pnlCourses.TabIndex = 2;
            // 
            // dgvCourses
            // 
            this.dgvCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCourses.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvCourses.Location = new System.Drawing.Point(300, 0);
            this.dgvCourses.Name = "dgvCourses";
            this.dgvCourses.ReadOnly = true;
            this.dgvCourses.Size = new System.Drawing.Size(463, 436);
            this.dgvCourses.TabIndex = 29;
            this.dgvCourses.DoubleClick += new System.EventHandler(this.dgvCourses_DoubleClick);
            // 
            // btnCourseDelete
            // 
            this.btnCourseDelete.Location = new System.Drawing.Point(153, 320);
            this.btnCourseDelete.Name = "btnCourseDelete";
            this.btnCourseDelete.Size = new System.Drawing.Size(106, 33);
            this.btnCourseDelete.TabIndex = 28;
            this.btnCourseDelete.Text = "Delete";
            this.btnCourseDelete.UseVisualStyleBackColor = true;
            this.btnCourseDelete.Click += new System.EventHandler(this.btnCourseDelete_Click);
            // 
            // btnCourseSave
            // 
            this.btnCourseSave.Location = new System.Drawing.Point(153, 278);
            this.btnCourseSave.Name = "btnCourseSave";
            this.btnCourseSave.Size = new System.Drawing.Size(106, 33);
            this.btnCourseSave.TabIndex = 27;
            this.btnCourseSave.Text = "Save";
            this.btnCourseSave.UseVisualStyleBackColor = true;
            this.btnCourseSave.Click += new System.EventHandler(this.btnCourseSave_Click);
            // 
            // btnCourseReset
            // 
            this.btnCourseReset.Location = new System.Drawing.Point(35, 320);
            this.btnCourseReset.Name = "btnCourseReset";
            this.btnCourseReset.Size = new System.Drawing.Size(106, 33);
            this.btnCourseReset.TabIndex = 26;
            this.btnCourseReset.Text = "Reset";
            this.btnCourseReset.UseVisualStyleBackColor = true;
            this.btnCourseReset.Click += new System.EventHandler(this.btnCourseReset_Click);
            // 
            // btnCourseSearch
            // 
            this.btnCourseSearch.Location = new System.Drawing.Point(35, 278);
            this.btnCourseSearch.Name = "btnCourseSearch";
            this.btnCourseSearch.Size = new System.Drawing.Size(106, 33);
            this.btnCourseSearch.TabIndex = 25;
            this.btnCourseSearch.Text = "Search";
            this.btnCourseSearch.UseVisualStyleBackColor = true;
            this.btnCourseSearch.Click += new System.EventHandler(this.btnCourseSearch_Click);
            // 
            // txtCourseNumber
            // 
            this.txtCourseNumber.Location = new System.Drawing.Point(110, 127);
            this.txtCourseNumber.Name = "txtCourseNumber";
            this.txtCourseNumber.Size = new System.Drawing.Size(143, 20);
            this.txtCourseNumber.TabIndex = 22;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(110, 101);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(143, 20);
            this.txtDepartment.TabIndex = 21;
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Location = new System.Drawing.Point(40, 101);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(65, 13);
            this.lblDepartment.TabIndex = 18;
            this.lblDepartment.Text = "Department:";
            // 
            // lblCourseNumber
            // 
            this.lblCourseNumber.AutoSize = true;
            this.lblCourseNumber.Location = new System.Drawing.Point(21, 128);
            this.lblCourseNumber.Name = "lblCourseNumber";
            this.lblCourseNumber.Size = new System.Drawing.Size(83, 13);
            this.lblCourseNumber.TabIndex = 16;
            this.lblCourseNumber.Text = "Course Number:";
            // 
            // pnlRegisteredCourses
            // 
            this.pnlRegisteredCourses.Controls.Add(this.dgvRegCourses);
            this.pnlRegisteredCourses.Controls.Add(this.lstRegCourses);
            this.pnlRegisteredCourses.Controls.Add(this.btnRegDelete);
            this.pnlRegisteredCourses.Controls.Add(this.btnRegSave);
            this.pnlRegisteredCourses.Controls.Add(this.btnRegReset);
            this.pnlRegisteredCourses.Controls.Add(this.btnRegSearch);
            this.pnlRegisteredCourses.Controls.Add(this.txtRegCourseNumber);
            this.pnlRegisteredCourses.Controls.Add(this.txtRegSemester);
            this.pnlRegisteredCourses.Controls.Add(this.txtRegFirstName);
            this.pnlRegisteredCourses.Controls.Add(this.txtRegDepartment);
            this.pnlRegisteredCourses.Controls.Add(this.lblRegDepartment);
            this.pnlRegisteredCourses.Controls.Add(this.txtRegLastName);
            this.pnlRegisteredCourses.Controls.Add(this.lblRegLastName);
            this.pnlRegisteredCourses.Controls.Add(this.lblRegCourseNumber);
            this.pnlRegisteredCourses.Controls.Add(this.txtRegStudentId);
            this.pnlRegisteredCourses.Controls.Add(this.lblRegSemester);
            this.pnlRegisteredCourses.Controls.Add(this.lblRegStudentId);
            this.pnlRegisteredCourses.Controls.Add(this.lblRegFirstName);
            this.pnlRegisteredCourses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRegisteredCourses.Location = new System.Drawing.Point(0, 24);
            this.pnlRegisteredCourses.Name = "pnlRegisteredCourses";
            this.pnlRegisteredCourses.Size = new System.Drawing.Size(763, 436);
            this.pnlRegisteredCourses.TabIndex = 3;
            // 
            // dgvRegCourses
            // 
            this.dgvRegCourses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRegCourses.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvRegCourses.Location = new System.Drawing.Point(300, 0);
            this.dgvRegCourses.Name = "dgvRegCourses";
            this.dgvRegCourses.ReadOnly = true;
            this.dgvRegCourses.Size = new System.Drawing.Size(463, 436);
            this.dgvRegCourses.TabIndex = 37;
            this.dgvRegCourses.DoubleClick += new System.EventHandler(this.dgvRegCourses_DoubleClick);
            // 
            // lstRegCourses
            // 
            this.lstRegCourses.FormattingEnabled = true;
            this.lstRegCourses.Location = new System.Drawing.Point(35, 181);
            this.lstRegCourses.Name = "lstRegCourses";
            this.lstRegCourses.Size = new System.Drawing.Size(224, 82);
            this.lstRegCourses.TabIndex = 41;
            this.lstRegCourses.SelectedIndexChanged += new System.EventHandler(this.lstRegCourses_SelectedIndexChanged);
            // 
            // btnRegDelete
            // 
            this.btnRegDelete.Location = new System.Drawing.Point(153, 315);
            this.btnRegDelete.Name = "btnRegDelete";
            this.btnRegDelete.Size = new System.Drawing.Size(106, 33);
            this.btnRegDelete.TabIndex = 40;
            this.btnRegDelete.Text = "Delete";
            this.btnRegDelete.UseVisualStyleBackColor = true;
            this.btnRegDelete.Click += new System.EventHandler(this.btnRegDelete_Click);
            // 
            // btnRegSave
            // 
            this.btnRegSave.Location = new System.Drawing.Point(153, 273);
            this.btnRegSave.Name = "btnRegSave";
            this.btnRegSave.Size = new System.Drawing.Size(106, 33);
            this.btnRegSave.TabIndex = 37;
            this.btnRegSave.Text = "Save";
            this.btnRegSave.UseVisualStyleBackColor = true;
            this.btnRegSave.Click += new System.EventHandler(this.btnRegSave_Click);
            // 
            // btnRegReset
            // 
            this.btnRegReset.Location = new System.Drawing.Point(35, 315);
            this.btnRegReset.Name = "btnRegReset";
            this.btnRegReset.Size = new System.Drawing.Size(106, 33);
            this.btnRegReset.TabIndex = 39;
            this.btnRegReset.Text = "Reset";
            this.btnRegReset.UseVisualStyleBackColor = true;
            this.btnRegReset.Click += new System.EventHandler(this.btnRegReset_Click);
            // 
            // btnRegSearch
            // 
            this.btnRegSearch.Location = new System.Drawing.Point(35, 273);
            this.btnRegSearch.Name = "btnRegSearch";
            this.btnRegSearch.Size = new System.Drawing.Size(106, 33);
            this.btnRegSearch.TabIndex = 38;
            this.btnRegSearch.Text = "Search";
            this.btnRegSearch.UseVisualStyleBackColor = true;
            this.btnRegSearch.Click += new System.EventHandler(this.btnRegSearch_Click);
            // 
            // txtRegCourseNumber
            // 
            this.txtRegCourseNumber.Location = new System.Drawing.Point(116, 146);
            this.txtRegCourseNumber.Name = "txtRegCourseNumber";
            this.txtRegCourseNumber.Size = new System.Drawing.Size(143, 20);
            this.txtRegCourseNumber.TabIndex = 36;
            // 
            // txtRegSemester
            // 
            this.txtRegSemester.Location = new System.Drawing.Point(116, 96);
            this.txtRegSemester.Name = "txtRegSemester";
            this.txtRegSemester.Size = new System.Drawing.Size(143, 20);
            this.txtRegSemester.TabIndex = 34;
            // 
            // txtRegFirstName
            // 
            this.txtRegFirstName.Location = new System.Drawing.Point(116, 44);
            this.txtRegFirstName.Name = "txtRegFirstName";
            this.txtRegFirstName.Size = new System.Drawing.Size(143, 20);
            this.txtRegFirstName.TabIndex = 32;
            // 
            // txtRegDepartment
            // 
            this.txtRegDepartment.Location = new System.Drawing.Point(116, 120);
            this.txtRegDepartment.Name = "txtRegDepartment";
            this.txtRegDepartment.Size = new System.Drawing.Size(143, 20);
            this.txtRegDepartment.TabIndex = 35;
            // 
            // lblRegDepartment
            // 
            this.lblRegDepartment.AutoSize = true;
            this.lblRegDepartment.Location = new System.Drawing.Point(50, 120);
            this.lblRegDepartment.Name = "lblRegDepartment";
            this.lblRegDepartment.Size = new System.Drawing.Size(65, 13);
            this.lblRegDepartment.TabIndex = 30;
            this.lblRegDepartment.Text = "Department:";
            // 
            // txtRegLastName
            // 
            this.txtRegLastName.Location = new System.Drawing.Point(116, 70);
            this.txtRegLastName.Name = "txtRegLastName";
            this.txtRegLastName.Size = new System.Drawing.Size(143, 20);
            this.txtRegLastName.TabIndex = 33;
            // 
            // lblRegLastName
            // 
            this.lblRegLastName.AutoSize = true;
            this.lblRegLastName.Location = new System.Drawing.Point(54, 70);
            this.lblRegLastName.Name = "lblRegLastName";
            this.lblRegLastName.Size = new System.Drawing.Size(61, 13);
            this.lblRegLastName.TabIndex = 30;
            this.lblRegLastName.Text = "Last Name:";
            // 
            // lblRegCourseNumber
            // 
            this.lblRegCourseNumber.AutoSize = true;
            this.lblRegCourseNumber.Location = new System.Drawing.Point(32, 146);
            this.lblRegCourseNumber.Name = "lblRegCourseNumber";
            this.lblRegCourseNumber.Size = new System.Drawing.Size(83, 13);
            this.lblRegCourseNumber.TabIndex = 29;
            this.lblRegCourseNumber.Text = "Course Number:";
            // 
            // txtRegStudentId
            // 
            this.txtRegStudentId.Location = new System.Drawing.Point(116, 18);
            this.txtRegStudentId.Name = "txtRegStudentId";
            this.txtRegStudentId.Size = new System.Drawing.Size(143, 20);
            this.txtRegStudentId.TabIndex = 31;
            // 
            // lblRegSemester
            // 
            this.lblRegSemester.AutoSize = true;
            this.lblRegSemester.Location = new System.Drawing.Point(60, 96);
            this.lblRegSemester.Name = "lblRegSemester";
            this.lblRegSemester.Size = new System.Drawing.Size(54, 13);
            this.lblRegSemester.TabIndex = 29;
            this.lblRegSemester.Text = "Semester:";
            // 
            // lblRegStudentId
            // 
            this.lblRegStudentId.AutoSize = true;
            this.lblRegStudentId.Location = new System.Drawing.Point(54, 18);
            this.lblRegStudentId.Name = "lblRegStudentId";
            this.lblRegStudentId.Size = new System.Drawing.Size(61, 13);
            this.lblRegStudentId.TabIndex = 30;
            this.lblRegStudentId.Text = "Student ID:";
            // 
            // lblRegFirstName
            // 
            this.lblRegFirstName.AutoSize = true;
            this.lblRegFirstName.Location = new System.Drawing.Point(54, 44);
            this.lblRegFirstName.Name = "lblRegFirstName";
            this.lblRegFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblRegFirstName.TabIndex = 29;
            this.lblRegFirstName.Text = "First Name:";
            // 
            // pnlExams
            // 
            this.pnlExams.Controls.Add(this.dgvExam);
            this.pnlExams.Controls.Add(this.lstExam);
            this.pnlExams.Controls.Add(this.btnExamDelete);
            this.pnlExams.Controls.Add(this.btnExamSave);
            this.pnlExams.Controls.Add(this.btnExamReset);
            this.pnlExams.Controls.Add(this.btnExamSearch);
            this.pnlExams.Controls.Add(this.txtExamName);
            this.pnlExams.Controls.Add(this.txtExamCourseNumber);
            this.pnlExams.Controls.Add(this.txtExamDepartment);
            this.pnlExams.Controls.Add(this.txtExamFirstName);
            this.pnlExams.Controls.Add(this.txtExamGrade);
            this.pnlExams.Controls.Add(this.lblExamGrade);
            this.pnlExams.Controls.Add(this.txtExamLastName);
            this.pnlExams.Controls.Add(this.lblExamLastName);
            this.pnlExams.Controls.Add(this.txtExamSemester);
            this.pnlExams.Controls.Add(this.txtExamStudentId);
            this.pnlExams.Controls.Add(this.lblExamSemester);
            this.pnlExams.Controls.Add(this.lblExamCourseNumber);
            this.pnlExams.Controls.Add(this.lblExamName);
            this.pnlExams.Controls.Add(this.lblExamDepartment);
            this.pnlExams.Controls.Add(this.lblExamStudentId);
            this.pnlExams.Controls.Add(this.lblExamFirstName);
            this.pnlExams.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlExams.Location = new System.Drawing.Point(0, 24);
            this.pnlExams.Name = "pnlExams";
            this.pnlExams.Size = new System.Drawing.Size(763, 436);
            this.pnlExams.TabIndex = 4;
            // 
            // dgvExam
            // 
            this.dgvExam.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExam.Dock = System.Windows.Forms.DockStyle.Right;
            this.dgvExam.Location = new System.Drawing.Point(300, 0);
            this.dgvExam.Name = "dgvExam";
            this.dgvExam.ReadOnly = true;
            this.dgvExam.Size = new System.Drawing.Size(463, 436);
            this.dgvExam.TabIndex = 59;
            this.dgvExam.DoubleClick += new System.EventHandler(this.dgvExam_DoubleClick);
            // 
            // lstExam
            // 
            this.lstExam.FormattingEnabled = true;
            this.lstExam.Location = new System.Drawing.Point(29, 186);
            this.lstExam.Name = "lstExam";
            this.lstExam.Size = new System.Drawing.Size(224, 82);
            this.lstExam.TabIndex = 56;
            this.lstExam.SelectedIndexChanged += new System.EventHandler(this.lstExam_SelectedIndexChanged);
            // 
            // btnExamDelete
            // 
            this.btnExamDelete.Location = new System.Drawing.Point(147, 320);
            this.btnExamDelete.Name = "btnExamDelete";
            this.btnExamDelete.Size = new System.Drawing.Size(106, 33);
            this.btnExamDelete.TabIndex = 60;
            this.btnExamDelete.Text = "Delete";
            this.btnExamDelete.UseVisualStyleBackColor = true;
            this.btnExamDelete.Click += new System.EventHandler(this.btnExamDelete_Click);
            // 
            // btnExamSave
            // 
            this.btnExamSave.Location = new System.Drawing.Point(147, 278);
            this.btnExamSave.Name = "btnExamSave";
            this.btnExamSave.Size = new System.Drawing.Size(106, 33);
            this.btnExamSave.TabIndex = 58;
            this.btnExamSave.Text = "Save";
            this.btnExamSave.UseVisualStyleBackColor = true;
            this.btnExamSave.Click += new System.EventHandler(this.btnExamSave_Click);
            // 
            // btnExamReset
            // 
            this.btnExamReset.Location = new System.Drawing.Point(29, 320);
            this.btnExamReset.Name = "btnExamReset";
            this.btnExamReset.Size = new System.Drawing.Size(106, 33);
            this.btnExamReset.TabIndex = 59;
            this.btnExamReset.Text = "Reset";
            this.btnExamReset.UseVisualStyleBackColor = true;
            this.btnExamReset.Click += new System.EventHandler(this.btnExamReset_Click);
            // 
            // btnExamSearch
            // 
            this.btnExamSearch.Location = new System.Drawing.Point(29, 278);
            this.btnExamSearch.Name = "btnExamSearch";
            this.btnExamSearch.Size = new System.Drawing.Size(106, 33);
            this.btnExamSearch.TabIndex = 57;
            this.btnExamSearch.Text = "Search";
            this.btnExamSearch.UseVisualStyleBackColor = true;
            this.btnExamSearch.Click += new System.EventHandler(this.btnExamSearch_Click);
            // 
            // txtExamName
            // 
            this.txtExamName.Location = new System.Drawing.Point(110, 138);
            this.txtExamName.Name = "txtExamName";
            this.txtExamName.Size = new System.Drawing.Size(143, 20);
            this.txtExamName.TabIndex = 54;
            // 
            // txtExamCourseNumber
            // 
            this.txtExamCourseNumber.Location = new System.Drawing.Point(206, 115);
            this.txtExamCourseNumber.Name = "txtExamCourseNumber";
            this.txtExamCourseNumber.Size = new System.Drawing.Size(47, 20);
            this.txtExamCourseNumber.TabIndex = 53;
            // 
            // txtExamDepartment
            // 
            this.txtExamDepartment.Location = new System.Drawing.Point(110, 115);
            this.txtExamDepartment.Name = "txtExamDepartment";
            this.txtExamDepartment.Size = new System.Drawing.Size(47, 20);
            this.txtExamDepartment.TabIndex = 52;
            // 
            // txtExamFirstName
            // 
            this.txtExamFirstName.Location = new System.Drawing.Point(110, 37);
            this.txtExamFirstName.Name = "txtExamFirstName";
            this.txtExamFirstName.Size = new System.Drawing.Size(143, 20);
            this.txtExamFirstName.TabIndex = 49;
            // 
            // txtExamGrade
            // 
            this.txtExamGrade.Location = new System.Drawing.Point(110, 162);
            this.txtExamGrade.Name = "txtExamGrade";
            this.txtExamGrade.Size = new System.Drawing.Size(143, 20);
            this.txtExamGrade.TabIndex = 55;
            // 
            // lblExamGrade
            // 
            this.lblExamGrade.AutoSize = true;
            this.lblExamGrade.Location = new System.Drawing.Point(40, 164);
            this.lblExamGrade.Name = "lblExamGrade";
            this.lblExamGrade.Size = new System.Drawing.Size(68, 13);
            this.lblExamGrade.TabIndex = 47;
            this.lblExamGrade.Text = "Exam Grade:";
            // 
            // txtExamLastName
            // 
            this.txtExamLastName.Location = new System.Drawing.Point(110, 63);
            this.txtExamLastName.Name = "txtExamLastName";
            this.txtExamLastName.Size = new System.Drawing.Size(143, 20);
            this.txtExamLastName.TabIndex = 50;
            // 
            // lblExamLastName
            // 
            this.lblExamLastName.AutoSize = true;
            this.lblExamLastName.Location = new System.Drawing.Point(48, 63);
            this.lblExamLastName.Name = "lblExamLastName";
            this.lblExamLastName.Size = new System.Drawing.Size(61, 13);
            this.lblExamLastName.TabIndex = 45;
            this.lblExamLastName.Text = "Last Name:";
            // 
            // txtExamSemester
            // 
            this.txtExamSemester.Location = new System.Drawing.Point(110, 89);
            this.txtExamSemester.Name = "txtExamSemester";
            this.txtExamSemester.Size = new System.Drawing.Size(143, 20);
            this.txtExamSemester.TabIndex = 51;
            // 
            // txtExamStudentId
            // 
            this.txtExamStudentId.Location = new System.Drawing.Point(110, 11);
            this.txtExamStudentId.Name = "txtExamStudentId";
            this.txtExamStudentId.Size = new System.Drawing.Size(143, 20);
            this.txtExamStudentId.TabIndex = 48;
            // 
            // lblExamSemester
            // 
            this.lblExamSemester.AutoSize = true;
            this.lblExamSemester.Location = new System.Drawing.Point(54, 89);
            this.lblExamSemester.Name = "lblExamSemester";
            this.lblExamSemester.Size = new System.Drawing.Size(54, 13);
            this.lblExamSemester.TabIndex = 46;
            this.lblExamSemester.Text = "Semester:";
            // 
            // lblExamCourseNumber
            // 
            this.lblExamCourseNumber.AutoSize = true;
            this.lblExamCourseNumber.Location = new System.Drawing.Point(163, 115);
            this.lblExamCourseNumber.Name = "lblExamCourseNumber";
            this.lblExamCourseNumber.Size = new System.Drawing.Size(43, 13);
            this.lblExamCourseNumber.TabIndex = 42;
            this.lblExamCourseNumber.Text = "Course:";
            // 
            // lblExamName
            // 
            this.lblExamName.AutoSize = true;
            this.lblExamName.Location = new System.Drawing.Point(42, 139);
            this.lblExamName.Name = "lblExamName";
            this.lblExamName.Size = new System.Drawing.Size(67, 13);
            this.lblExamName.TabIndex = 43;
            this.lblExamName.Text = "Exam Name:";
            // 
            // lblExamDepartment
            // 
            this.lblExamDepartment.AutoSize = true;
            this.lblExamDepartment.Location = new System.Drawing.Point(43, 115);
            this.lblExamDepartment.Name = "lblExamDepartment";
            this.lblExamDepartment.Size = new System.Drawing.Size(65, 13);
            this.lblExamDepartment.TabIndex = 42;
            this.lblExamDepartment.Text = "Department:";
            // 
            // lblExamStudentId
            // 
            this.lblExamStudentId.AutoSize = true;
            this.lblExamStudentId.Location = new System.Drawing.Point(47, 11);
            this.lblExamStudentId.Name = "lblExamStudentId";
            this.lblExamStudentId.Size = new System.Drawing.Size(61, 13);
            this.lblExamStudentId.TabIndex = 46;
            this.lblExamStudentId.Text = "Student ID:";
            // 
            // lblExamFirstName
            // 
            this.lblExamFirstName.AutoSize = true;
            this.lblExamFirstName.Location = new System.Drawing.Point(48, 37);
            this.lblExamFirstName.Name = "lblExamFirstName";
            this.lblExamFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblExamFirstName.TabIndex = 42;
            this.lblExamFirstName.Text = "First Name:";
            // 
            // pnlGpa
            // 
            this.pnlGpa.Controls.Add(this.btnGpaReset);
            this.pnlGpa.Controls.Add(this.btnGpaSearch);
            this.pnlGpa.Controls.Add(this.txtGpaOverall);
            this.pnlGpa.Controls.Add(this.txtGpaSemester);
            this.pnlGpa.Controls.Add(this.txtGpaLastName);
            this.pnlGpa.Controls.Add(this.txtGpaStudentId);
            this.pnlGpa.Controls.Add(this.txtGpaFirstName);
            this.pnlGpa.Controls.Add(this.lstGpaCourses);
            this.pnlGpa.Controls.Add(this.lblOverallGpa);
            this.pnlGpa.Controls.Add(this.lblSemester);
            this.pnlGpa.Controls.Add(this.lblGpaStudentId);
            this.pnlGpa.Controls.Add(this.lblGpaLastName);
            this.pnlGpa.Controls.Add(this.lblGpaFirstName);
            this.pnlGpa.Controls.Add(this.pnlGpaCourseGrades);
            this.pnlGpa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGpa.Location = new System.Drawing.Point(0, 24);
            this.pnlGpa.Name = "pnlGpa";
            this.pnlGpa.Size = new System.Drawing.Size(763, 436);
            this.pnlGpa.TabIndex = 5;
            // 
            // btnGpaReset
            // 
            this.btnGpaReset.Location = new System.Drawing.Point(180, 342);
            this.btnGpaReset.Name = "btnGpaReset";
            this.btnGpaReset.Size = new System.Drawing.Size(118, 23);
            this.btnGpaReset.TabIndex = 15;
            this.btnGpaReset.Text = "Reset";
            this.btnGpaReset.UseVisualStyleBackColor = true;
            this.btnGpaReset.Click += new System.EventHandler(this.btnGpaReset_Click);
            // 
            // btnGpaSearch
            // 
            this.btnGpaSearch.Location = new System.Drawing.Point(51, 342);
            this.btnGpaSearch.Name = "btnGpaSearch";
            this.btnGpaSearch.Size = new System.Drawing.Size(120, 23);
            this.btnGpaSearch.TabIndex = 15;
            this.btnGpaSearch.Text = "Search";
            this.btnGpaSearch.UseVisualStyleBackColor = true;
            this.btnGpaSearch.Click += new System.EventHandler(this.btnGpaSearch_Click);
            // 
            // txtGpaOverall
            // 
            this.txtGpaOverall.Enabled = false;
            this.txtGpaOverall.Location = new System.Drawing.Point(115, 277);
            this.txtGpaOverall.Name = "txtGpaOverall";
            this.txtGpaOverall.Size = new System.Drawing.Size(183, 20);
            this.txtGpaOverall.TabIndex = 10;
            // 
            // txtGpaSemester
            // 
            this.txtGpaSemester.Location = new System.Drawing.Point(115, 88);
            this.txtGpaSemester.Name = "txtGpaSemester";
            this.txtGpaSemester.Size = new System.Drawing.Size(183, 20);
            this.txtGpaSemester.TabIndex = 11;
            // 
            // txtGpaLastName
            // 
            this.txtGpaLastName.Location = new System.Drawing.Point(115, 63);
            this.txtGpaLastName.Name = "txtGpaLastName";
            this.txtGpaLastName.Size = new System.Drawing.Size(183, 20);
            this.txtGpaLastName.TabIndex = 12;
            // 
            // txtGpaStudentId
            // 
            this.txtGpaStudentId.Location = new System.Drawing.Point(115, 12);
            this.txtGpaStudentId.Name = "txtGpaStudentId";
            this.txtGpaStudentId.Size = new System.Drawing.Size(183, 20);
            this.txtGpaStudentId.TabIndex = 13;
            // 
            // txtGpaFirstName
            // 
            this.txtGpaFirstName.Location = new System.Drawing.Point(115, 38);
            this.txtGpaFirstName.Name = "txtGpaFirstName";
            this.txtGpaFirstName.Size = new System.Drawing.Size(183, 20);
            this.txtGpaFirstName.TabIndex = 13;
            // 
            // lstGpaCourses
            // 
            this.lstGpaCourses.FormattingEnabled = true;
            this.lstGpaCourses.Location = new System.Drawing.Point(51, 127);
            this.lstGpaCourses.Name = "lstGpaCourses";
            this.lstGpaCourses.Size = new System.Drawing.Size(247, 134);
            this.lstGpaCourses.TabIndex = 9;
            this.lstGpaCourses.SelectedIndexChanged += new System.EventHandler(this.lstGpaCourses_SelectedIndexChanged);
            // 
            // lblOverallGpa
            // 
            this.lblOverallGpa.AutoSize = true;
            this.lblOverallGpa.Location = new System.Drawing.Point(48, 280);
            this.lblOverallGpa.Name = "lblOverallGpa";
            this.lblOverallGpa.Size = new System.Drawing.Size(68, 13);
            this.lblOverallGpa.TabIndex = 5;
            this.lblOverallGpa.Text = "Overall GPA:";
            // 
            // lblSemester
            // 
            this.lblSemester.AutoSize = true;
            this.lblSemester.Location = new System.Drawing.Point(48, 91);
            this.lblSemester.Name = "lblSemester";
            this.lblSemester.Size = new System.Drawing.Size(54, 13);
            this.lblSemester.TabIndex = 6;
            this.lblSemester.Text = "Semester:";
            // 
            // lblGpaStudentId
            // 
            this.lblGpaStudentId.AutoSize = true;
            this.lblGpaStudentId.Location = new System.Drawing.Point(48, 12);
            this.lblGpaStudentId.Name = "lblGpaStudentId";
            this.lblGpaStudentId.Size = new System.Drawing.Size(61, 13);
            this.lblGpaStudentId.TabIndex = 8;
            this.lblGpaStudentId.Text = "Student ID:";
            // 
            // lblGpaLastName
            // 
            this.lblGpaLastName.AutoSize = true;
            this.lblGpaLastName.Location = new System.Drawing.Point(48, 66);
            this.lblGpaLastName.Name = "lblGpaLastName";
            this.lblGpaLastName.Size = new System.Drawing.Size(61, 13);
            this.lblGpaLastName.TabIndex = 7;
            this.lblGpaLastName.Text = "Last Name:";
            // 
            // lblGpaFirstName
            // 
            this.lblGpaFirstName.AutoSize = true;
            this.lblGpaFirstName.Location = new System.Drawing.Point(48, 38);
            this.lblGpaFirstName.Name = "lblGpaFirstName";
            this.lblGpaFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblGpaFirstName.TabIndex = 8;
            this.lblGpaFirstName.Text = "First Name:";
            // 
            // pnlGpaCourseGrades
            // 
            this.pnlGpaCourseGrades.Controls.Add(this.dgvGpa);
            this.pnlGpaCourseGrades.Controls.Add(this.lstGpaExamNamesAndGrades);
            this.pnlGpaCourseGrades.Controls.Add(this.txtGpa);
            this.pnlGpaCourseGrades.Controls.Add(this.txtGpaAverage);
            this.pnlGpaCourseGrades.Controls.Add(this.txtGpaCourse);
            this.pnlGpaCourseGrades.Controls.Add(this.lblGpa);
            this.pnlGpaCourseGrades.Controls.Add(this.lblGpaAverage);
            this.pnlGpaCourseGrades.Controls.Add(this.lblGpaCourse);
            this.pnlGpaCourseGrades.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlGpaCourseGrades.Location = new System.Drawing.Point(377, 0);
            this.pnlGpaCourseGrades.Name = "pnlGpaCourseGrades";
            this.pnlGpaCourseGrades.Size = new System.Drawing.Size(386, 436);
            this.pnlGpaCourseGrades.TabIndex = 4;
            // 
            // dgvGpa
            // 
            this.dgvGpa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGpa.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvGpa.Location = new System.Drawing.Point(0, 286);
            this.dgvGpa.Name = "dgvGpa";
            this.dgvGpa.ReadOnly = true;
            this.dgvGpa.Size = new System.Drawing.Size(386, 150);
            this.dgvGpa.TabIndex = 14;
            this.dgvGpa.DoubleClick += new System.EventHandler(this.dgvGpa_DoubleClick);
            // 
            // lstGpaExamNamesAndGrades
            // 
            this.lstGpaExamNamesAndGrades.FormattingEnabled = true;
            this.lstGpaExamNamesAndGrades.Location = new System.Drawing.Point(73, 120);
            this.lstGpaExamNamesAndGrades.Name = "lstGpaExamNamesAndGrades";
            this.lstGpaExamNamesAndGrades.Size = new System.Drawing.Size(220, 147);
            this.lstGpaExamNamesAndGrades.TabIndex = 2;
            // 
            // txtGpa
            // 
            this.txtGpa.Enabled = false;
            this.txtGpa.Location = new System.Drawing.Point(135, 74);
            this.txtGpa.Name = "txtGpa";
            this.txtGpa.Size = new System.Drawing.Size(100, 20);
            this.txtGpa.TabIndex = 1;
            // 
            // txtGpaAverage
            // 
            this.txtGpaAverage.Enabled = false;
            this.txtGpaAverage.Location = new System.Drawing.Point(135, 41);
            this.txtGpaAverage.Name = "txtGpaAverage";
            this.txtGpaAverage.Size = new System.Drawing.Size(100, 20);
            this.txtGpaAverage.TabIndex = 1;
            // 
            // txtGpaCourse
            // 
            this.txtGpaCourse.Enabled = false;
            this.txtGpaCourse.Location = new System.Drawing.Point(135, 12);
            this.txtGpaCourse.Name = "txtGpaCourse";
            this.txtGpaCourse.Size = new System.Drawing.Size(100, 20);
            this.txtGpaCourse.TabIndex = 1;
            // 
            // lblGpa
            // 
            this.lblGpa.AutoSize = true;
            this.lblGpa.Location = new System.Drawing.Point(70, 81);
            this.lblGpa.Name = "lblGpa";
            this.lblGpa.Size = new System.Drawing.Size(32, 13);
            this.lblGpa.TabIndex = 0;
            this.lblGpa.Text = "GPA:";
            // 
            // lblGpaAverage
            // 
            this.lblGpaAverage.AutoSize = true;
            this.lblGpaAverage.Location = new System.Drawing.Point(70, 44);
            this.lblGpaAverage.Name = "lblGpaAverage";
            this.lblGpaAverage.Size = new System.Drawing.Size(50, 13);
            this.lblGpaAverage.TabIndex = 0;
            this.lblGpaAverage.Text = "Average:";
            // 
            // lblGpaCourse
            // 
            this.lblGpaCourse.AutoSize = true;
            this.lblGpaCourse.Location = new System.Drawing.Point(70, 15);
            this.lblGpaCourse.Name = "lblGpaCourse";
            this.lblGpaCourse.Size = new System.Drawing.Size(43, 13);
            this.lblGpaCourse.TabIndex = 0;
            this.lblGpaCourse.Text = "Course:";
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 460);
            this.Controls.Add(this.pnlGpa);
            this.Controls.Add(this.pnlExams);
            this.Controls.Add(this.pnlRegisteredCourses);
            this.Controls.Add(this.pnlCourses);
            this.Controls.Add(this.pnlUsers);
            this.Controls.Add(this.msOptions);
            this.MainMenuStrip = this.msOptions;
            this.Name = "Admin";
            this.Text = "Student Informatioin Management System (Admin)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Admin_FormClosing);
            this.Load += new System.EventHandler(this.Admin_Load);
            this.msOptions.ResumeLayout(false);
            this.msOptions.PerformLayout();
            this.pnlUsers.ResumeLayout(false);
            this.pnlUsers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsers)).EndInit();
            this.pnlCourses.ResumeLayout(false);
            this.pnlCourses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCourses)).EndInit();
            this.pnlRegisteredCourses.ResumeLayout(false);
            this.pnlRegisteredCourses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegCourses)).EndInit();
            this.pnlExams.ResumeLayout(false);
            this.pnlExams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExam)).EndInit();
            this.pnlGpa.ResumeLayout(false);
            this.pnlGpa.PerformLayout();
            this.pnlGpaCourseGrades.ResumeLayout(false);
            this.pnlGpaCourseGrades.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGpa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msOptions;
        private System.Windows.Forms.ToolStripMenuItem menuOptions;
        private System.Windows.Forms.ToolStripMenuItem menuUsers;
        private System.Windows.Forms.ToolStripMenuItem menuCourses;
        private System.Windows.Forms.ToolStripMenuItem menuStudents;
        private System.Windows.Forms.ToolStripMenuItem menuRegisteredCourses;
        private System.Windows.Forms.ToolStripMenuItem menuExams;
        private System.Windows.Forms.ToolStripMenuItem menuGpa;
        private System.Windows.Forms.Panel pnlUsers;
        private System.Windows.Forms.DataGridView dgvUsers;
        private System.Windows.Forms.Button btnUserDelete;
        private System.Windows.Forms.Button btnUserSave;
        private System.Windows.Forms.Button btnUserReset;
        private System.Windows.Forms.Button btnUserSearch;
        private System.Windows.Forms.ComboBox cmbUserStatus;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Label lblUserStatus;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblUserId;
        private System.Windows.Forms.Panel pnlCourses;
        private System.Windows.Forms.DataGridView dgvCourses;
        private System.Windows.Forms.Button btnCourseDelete;
        private System.Windows.Forms.Button btnCourseSave;
        private System.Windows.Forms.Button btnCourseReset;
        private System.Windows.Forms.Button btnCourseSearch;
        private System.Windows.Forms.TextBox txtCourseNumber;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Label lblCourseNumber;
        private System.Windows.Forms.Panel pnlRegisteredCourses;
        private System.Windows.Forms.DataGridView dgvRegCourses;
        private System.Windows.Forms.Button btnRegDelete;
        private System.Windows.Forms.Button btnRegSave;
        private System.Windows.Forms.Button btnRegReset;
        private System.Windows.Forms.Button btnRegSearch;
        private System.Windows.Forms.TextBox txtRegFirstName;
        private System.Windows.Forms.TextBox txtRegStudentId;
        private System.Windows.Forms.Label lblRegStudentId;
        private System.Windows.Forms.Label lblRegFirstName;
        private System.Windows.Forms.ListBox lstRegCourses;
        private System.Windows.Forms.TextBox txtRegCourseNumber;
        private System.Windows.Forms.TextBox txtRegSemester;
        private System.Windows.Forms.TextBox txtRegDepartment;
        private System.Windows.Forms.Label lblRegDepartment;
        private System.Windows.Forms.TextBox txtRegLastName;
        private System.Windows.Forms.Label lblRegLastName;
        private System.Windows.Forms.Label lblRegCourseNumber;
        private System.Windows.Forms.Label lblRegSemester;
        private System.Windows.Forms.Panel pnlExams;
        private System.Windows.Forms.DataGridView dgvExam;
        private System.Windows.Forms.ListBox lstExam;
        private System.Windows.Forms.Button btnExamDelete;
        private System.Windows.Forms.Button btnExamSave;
        private System.Windows.Forms.Button btnExamReset;
        private System.Windows.Forms.Button btnExamSearch;
        private System.Windows.Forms.TextBox txtExamName;
        private System.Windows.Forms.TextBox txtExamFirstName;
        private System.Windows.Forms.TextBox txtExamGrade;
        private System.Windows.Forms.Label lblExamGrade;
        private System.Windows.Forms.TextBox txtExamLastName;
        private System.Windows.Forms.Label lblExamLastName;
        private System.Windows.Forms.TextBox txtExamStudentId;
        private System.Windows.Forms.Label lblExamName;
        private System.Windows.Forms.Label lblExamStudentId;
        private System.Windows.Forms.Label lblExamFirstName;
        private System.Windows.Forms.TextBox txtExamDepartment;
        private System.Windows.Forms.TextBox txtExamSemester;
        private System.Windows.Forms.Label lblExamSemester;
        private System.Windows.Forms.Label lblExamDepartment;
        private System.Windows.Forms.TextBox txtExamCourseNumber;
        private System.Windows.Forms.Label lblExamCourseNumber;
        private System.Windows.Forms.Panel pnlGpa;
        private System.Windows.Forms.Button btnGpaReset;
        private System.Windows.Forms.Button btnGpaSearch;
        private System.Windows.Forms.TextBox txtGpaOverall;
        private System.Windows.Forms.TextBox txtGpaSemester;
        private System.Windows.Forms.TextBox txtGpaLastName;
        private System.Windows.Forms.TextBox txtGpaStudentId;
        private System.Windows.Forms.TextBox txtGpaFirstName;
        private System.Windows.Forms.ListBox lstGpaCourses;
        private System.Windows.Forms.Label lblOverallGpa;
        private System.Windows.Forms.Label lblSemester;
        private System.Windows.Forms.Label lblGpaStudentId;
        private System.Windows.Forms.Label lblGpaLastName;
        private System.Windows.Forms.Label lblGpaFirstName;
        private System.Windows.Forms.Panel pnlGpaCourseGrades;
        private System.Windows.Forms.DataGridView dgvGpa;
        private System.Windows.Forms.ListBox lstGpaExamNamesAndGrades;
        private System.Windows.Forms.TextBox txtGpa;
        private System.Windows.Forms.TextBox txtGpaAverage;
        private System.Windows.Forms.TextBox txtGpaCourse;
        private System.Windows.Forms.Label lblGpa;
        private System.Windows.Forms.Label lblGpaAverage;
        private System.Windows.Forms.Label lblGpaCourse;
    }
}