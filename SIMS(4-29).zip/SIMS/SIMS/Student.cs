﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace SIMS
{
    public partial class Student : Form
    {
        SqlConnection con;
        string connectionString;
        string studentId;

        public Student(string id , string status)
        {
            InitializeComponent();

            if (status == "student")
            {
                pnlStudentMain.Visible = true;

                connectionString = ConfigurationManager.ConnectionStrings["SIMS.Properties.Settings.SIMSConnectionString"].ConnectionString;

                PopulateFields(id);

            }
            else if (status == "admin")
            {
                pnlStudentMain.Visible = false;
            }
            else
            {
                MessageBox.Show("User Status Error");
                this.Close();
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
        }

        private void PopulateFields(string id)
        {
            studentId = id;
            string query = "SELECT um.fName, um.lName, sg.semester, sg.overallGpa"
                + " FROM userMaster um INNER JOIN studentGpa sg ON um.userId = sg.studentId"
                + " WHERE userId = @userId AND semester = 'Spring 2017'";

            using (con = new SqlConnection(connectionString))
            using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
            {
                sda.SelectCommand.Parameters.AddWithValue("@userId", id);
                

                DataTable dt = new DataTable();
                sda.Fill(dt);
          
                txtFirstName.Text = dt.Rows[0][0].ToString();
                txtLastName.Text = dt.Rows[0][1].ToString();
                txtSemester.Text = dt.Rows[0][2].ToString();
                txtOverallGpa.Text = dt.Rows[0][3].ToString();


            }

            query = "SELECT concat(department, ' ', courseNumber) AS course, rc.courseId"
                + " FROM courses c INNER JOIN registeredCourses rc ON c.courseId = rc.courseId"
                + " INNER JOIN userMaster um On rc.studentId = um.userId"
                + " WHERE um.userId = @userId AND rc.semester = 'Spring 2017'";

            using (con = new SqlConnection(connectionString))
            using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
            {
                sda.SelectCommand.Parameters.AddWithValue("@userId", id);
                
                DataTable dt = new DataTable();
                sda.Fill(dt);

                lstCourses.DisplayMember = "course";
                lstCourses.ValueMember = "courseId";
                lstCourses.DataSource = dt;
            }

        }

        private void PopulateCoursePanel()
        {
            string query = "SELECT concat(c.department, ' ', c.courseNumber) AS course, rc.courseAvg, rc.courseGpa"
                + " FROM courses c INNER JOIN registeredCourses rc ON c.courseId = rc.courseId"
                + " INNER JOIN userMaster um ON rc.studentId = um.userId"
                + " WHERE um.userId = @studentId AND rc.courseId = @courseId AND rc.semester = 'Spring 2017'";

            using (con = new SqlConnection(connectionString))
            using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
            {

                sda.SelectCommand.Parameters.AddWithValue("@courseId", lstCourses.SelectedValue);
                sda.SelectCommand.Parameters.AddWithValue("@studentId", studentId);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                txtCourse.Text = dt.Rows[0][0].ToString();
                txtAverage.Text = dt.Rows[0][1].ToString();
                txtGpa.Text = dt.Rows[0][2].ToString();
            }

            query = "SELECT concat(examName, ' ', examGrade) as examList"
            + " FROM exams e INNER JOIN registeredCourses rc ON e.registeredId = rc.registeredId"
            + " INNER JOIN userMaster um ON rc.studentId = um.userId"
            + " WHERE um.userId = @studentId AND rc.courseId = @courseId AND semester = 'Spring 2017'";

            using (con = new SqlConnection(connectionString))
            using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
            {
                sda.SelectCommand.Parameters.AddWithValue("@courseId", lstCourses.SelectedValue);
                sda.SelectCommand.Parameters.AddWithValue("@studentId", studentId);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                lstExamNamesAndGrades.DisplayMember = "examList";
                lstExamNamesAndGrades.ValueMember = "examId";
                lstExamNamesAndGrades.DataSource = dt;

            }
        }

        private void lstCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateCoursePanel();
        }

        private void Student_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }
                else
                {
                    e.Cancel = true;
                }
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
}
