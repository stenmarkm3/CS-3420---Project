﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace SIMS
{
    public partial class Admin : Form
    {
        SqlConnection con;
        string connectionString;
        int courseId = 0;
        int regCourseId = 0;
        int examId = 0;

        public Admin()
        {
            InitializeComponent();
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sIMSDataSet.userMaster' table. You can move, or remove it, as needed.
            pnlCourses.Visible = false;
            pnlExams.Visible = false;
            pnlGpa.Visible = false;
            pnlRegisteredCourses.Visible = false;
            pnlUsers.Visible = false;
            connectionString = ConfigurationManager.ConnectionStrings["SIMS.Properties.Settings.SIMSConnectionString"].ConnectionString;
            con = new SqlConnection(connectionString);
        }

        private void menuUsers_Click(object sender, EventArgs e)
        {
            pnlCourses.Visible = false;
            pnlExams.Visible = false;
            pnlGpa.Visible = false;
            pnlRegisteredCourses.Visible = false;
            pnlUsers.Visible = true;

            UserReset();

        }


        private void btnUserSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                if (btnUserSave.Text == "Add")
                {
                    SqlCommand cmd = new SqlCommand("UserAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Add");
                    cmd.Parameters.AddWithValue("@userId", txtUserId.Text.Trim());
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
                    cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                    cmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                    cmd.Parameters.AddWithValue("@status", cmbUserStatus.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User added successfully");
                    UserReset();
                    FillUserDataGridView();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UserAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Edit");
                    cmd.Parameters.AddWithValue("@userId", txtUserId.Text);
                    cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
                    cmd.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
                    cmd.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
                    cmd.Parameters.AddWithValue("@status", cmbUserStatus.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User updated successfully");
                    UserReset();
                    FillUserDataGridView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        void FillUserDataGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("UserSearch", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.Parameters.AddWithValue("@userId", txtUserId.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@firstName", txtFirstName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@lastName", txtLastName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@status", cmbUserStatus.Text);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvUsers.DataSource = dt;
            con.Close();
        }

        private void btnUserReset_Click(object sender, EventArgs e)
        {
            UserReset();
        }

        void UserReset()
        {
            txtFirstName.Text = txtLastName.Text = txtPassword.Text = txtUserId.Text = "";
            cmbUserStatus.SelectedIndex = -1;
            btnUserSave.Text = "Add";
            btnUserDelete.Enabled = false;
        }

        private void btnUserSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillUserDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dgvUsers_DoubleClick(object sender, EventArgs e)
        {
            if (dgvUsers.CurrentRow.Index != -1)
            {
                txtUserId.Text = dgvUsers.CurrentRow.Cells[0].Value.ToString();
                txtPassword.Text = dgvUsers.CurrentRow.Cells[1].Value.ToString();
                txtFirstName.Text = dgvUsers.CurrentRow.Cells[2].Value.ToString();
                txtLastName.Text = dgvUsers.CurrentRow.Cells[3].Value.ToString();
                cmbUserStatus.Text = dgvUsers.CurrentRow.Cells[4].Value.ToString();

                btnUserSave.Text = "Update";
                btnUserDelete.Enabled = true;
                txtUserId.Enabled = false;
            }
        }

        private void btnUserDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlCommand cmd = new SqlCommand("UserDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userId", txtUserId.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User deleted successfully");
                UserReset();
                FillUserDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        private void menuCourses_Click(object sender, EventArgs e)
        {
            pnlCourses.Visible = true;
            pnlExams.Visible = false;
            pnlGpa.Visible = false;
            pnlRegisteredCourses.Visible = false;
            pnlUsers.Visible = false;

            CourseReset();
        }

        private void btnCourseSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                if (btnUserSave.Text == "Add")
                {
                    SqlCommand cmd = new SqlCommand("CourseAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Add");
                    cmd.Parameters.AddWithValue("@courseId", 0);
                    cmd.Parameters.AddWithValue("@department", txtDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", txtCourseNumber.Text.Trim());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course added successfully");
                    CourseReset();
                    FillCoursesDataGridView();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("CourseAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Edit");
                    cmd.Parameters.AddWithValue("@courseId", courseId);
                    cmd.Parameters.AddWithValue("@department", txtDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", txtCourseNumber.Text.Trim());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course updated successfully");
                    CourseReset();
                    FillCoursesDataGridView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        void FillCoursesDataGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("CourseSearch", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.Parameters.AddWithValue("@department", txtDepartment.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@courseNumber", txtCourseNumber.Text.Trim());
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvCourses.DataSource = dt;
            dgvCourses.Columns[0].Visible = false;
            con.Close();
        }

        private void btnCourseReset_Click(object sender, EventArgs e)
        {
            CourseReset();
        }

        void CourseReset()
        {
            txtDepartment.Text = txtCourseNumber.Text = "";
            btnCourseSave.Text = "Add";
            courseId = 0;
            btnCourseDelete.Enabled = false;
        }

        private void btnCourseSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillCoursesDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }

        }

        private void dgvCourses_DoubleClick(object sender, EventArgs e)
        {
            if (dgvCourses.CurrentRow.Index != -1)
            {
                courseId = Convert.ToInt32(dgvCourses.CurrentRow.Cells[0].Value.ToString());
                txtDepartment.Text = dgvCourses.CurrentRow.Cells[1].Value.ToString();
                txtCourseNumber.Text = dgvCourses.CurrentRow.Cells[2].Value.ToString();

                btnCourseSave.Text = "Update";
                btnCourseDelete.Enabled = true;
            }
        }

        private void btnCourseDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlCommand cmd = new SqlCommand("CourseDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@courseId", courseId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Course deleted successfully");
                CourseReset();
                FillCoursesDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        private void menuRegisteredCourses_Click(object sender, EventArgs e)
        {
            pnlCourses.Visible = false;
            pnlExams.Visible = false;
            pnlGpa.Visible = false;
            pnlRegisteredCourses.Visible = true;
            pnlUsers.Visible = false;

            RegCourseReset();
        }

        private void btnRegSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                if (btnRegSave.Text == "Add")
                {
                    SqlCommand cmd = new SqlCommand("RegCourseAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Add");
                    cmd.Parameters.AddWithValue("@regCourseId", 0);
                    cmd.Parameters.AddWithValue("@semester", txtRegSemester.Text.Trim());
                    cmd.Parameters.AddWithValue("@studentId", txtRegStudentId.Text.Trim());
                    cmd.Parameters.AddWithValue("@department", txtRegDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", txtRegCourseNumber.Text.Trim());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course added successfully");
                    RegCourseReset();
                    FillRegCoursesDataGridView();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("RegCourseAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Edit");
                    cmd.Parameters.AddWithValue("@regCourseId", regCourseId);
                    cmd.Parameters.AddWithValue("@semester", txtRegSemester.Text.Trim());
                    cmd.Parameters.AddWithValue("@studentId", txtRegStudentId.Text.Trim());
                    cmd.Parameters.AddWithValue("@department", txtRegDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", txtRegCourseNumber.Text.Trim());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course updated successfully");
                    RegCourseReset();
                    FillRegCoursesDataGridView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        void FillRegCoursesDataGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("RegCourseSearch", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.Parameters.AddWithValue("@studentId", txtRegStudentId.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@firstName", txtRegFirstName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@lastName", txtRegLastName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@semester", txtRegSemester.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@department", txtRegDepartment.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@courseNumber", txtRegCourseNumber.Text.Trim());
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvRegCourses.DataSource = dt;
            con.Close();
        }

        private void btnRegReset_Click(object sender, EventArgs e)
        {
            RegCourseReset();
        }

        void RegCourseReset()
        {
            txtRegStudentId.Text = txtRegFirstName.Text = txtRegLastName.Text = txtRegSemester.Text = txtRegDepartment.Text = txtRegCourseNumber.Text = "";
            btnRegSave.Text = "Add";
            regCourseId = 0;
            txtRegStudentId.Enabled = true;
            txtRegFirstName.Enabled = true;
            txtRegLastName.Enabled = true;
            txtRegSemester.Enabled = true;
            txtRegDepartment.Enabled = true;
            txtRegCourseNumber.Enabled = true;
            btnRegDelete.Enabled = false;
            btnRegSave.Enabled = true;
            PopulateRegCourseListBox("", "");
            FillRegCoursesDataGridView();

        }

        private void btnRegSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillRegCoursesDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dgvRegCourses_DoubleClick(object sender, EventArgs e)
        {
            if (dgvRegCourses.CurrentRow.Index != -1)
            {
                string studentId = dgvRegCourses.CurrentRow.Cells[0].Value.ToString();
                string semester = dgvRegCourses.CurrentRow.Cells[3].Value.ToString();

                txtRegStudentId.Text = studentId;
                txtRegStudentId.Enabled = false;
                txtRegFirstName.Text = dgvRegCourses.CurrentRow.Cells[1].Value.ToString();
                txtRegFirstName.Enabled = false;
                txtRegLastName.Text = dgvRegCourses.CurrentRow.Cells[2].Value.ToString();
                txtRegLastName.Enabled = false;
                txtRegSemester.Text = semester;
                txtRegSemester.Enabled = false;
                txtRegDepartment.Enabled = false;
                txtRegCourseNumber.Enabled = false;

                PopulateRegCourseListBox(studentId, semester);

                btnRegSave.Text = "Update";
                btnRegSave.Enabled = false;
                btnRegDelete.Enabled = true;
            }
        }

        private void btnRegDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlCommand cmd = new SqlCommand("RegCourseDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@regCourseId", regCourseId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Course deleted successfully");
                RegCourseReset();
                FillRegCoursesDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        void PopulateRegCourseListBox(string studentId, string semester)
        {


            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("RegCourseListBox", con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.AddWithValue("@studentId", studentId);
                sda.SelectCommand.Parameters.AddWithValue("@semester", semester);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                lstRegCourses.DisplayMember = "course";
                lstRegCourses.ValueMember = "courseId";
                lstRegCourses.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        private void lstRegCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateRegCourseTextFromList();
        }

        private void PopulateRegCourseTextFromList()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("SelectRegCourse", con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.AddWithValue("@courseId", lstRegCourses.SelectedValue);
                sda.SelectCommand.Parameters.AddWithValue("@studentId", txtRegStudentId.Text);
                sda.SelectCommand.Parameters.AddWithValue("@semester", txtRegSemester.Text);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                txtRegDepartment.Text = dt.Rows[0][0].ToString();
                txtRegCourseNumber.Text = dt.Rows[0][1].ToString();
                regCourseId = Convert.ToInt32(dt.Rows[0][2].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        private void menuExams_Click(object sender, EventArgs e)
        {
            pnlCourses.Visible = false;
            pnlExams.Visible = true;
            pnlGpa.Visible = false;
            pnlRegisteredCourses.Visible = false;
            pnlUsers.Visible = false;

            ExamReset();
        }

        private void btnExamSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                if (btnExamSave.Text == "Add")
                {
                    SqlCommand cmd = new SqlCommand("ExamAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Add");
                    cmd.Parameters.AddWithValue("@studentId", txtExamStudentId.Text.Trim());
                    cmd.Parameters.AddWithValue("@semester", txtExamSemester.Text.Trim());
                    cmd.Parameters.AddWithValue("@department", txtExamDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", Convert.ToInt32(txtExamCourseNumber.Text.Trim()));
                    cmd.Parameters.AddWithValue("@examId", 0);
                    cmd.Parameters.AddWithValue("@examName", txtExamName.Text.Trim());
                    cmd.Parameters.AddWithValue("@examGrade", Convert.ToInt32(txtExamGrade.Text.Trim()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Exam added successfully");
                    ExamReset();
                    FillExamDataGridView();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("ExamAddEdit", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@mode", "Edit");
                    cmd.Parameters.AddWithValue("@studentId", txtExamStudentId.Text.Trim());
                    cmd.Parameters.AddWithValue("@semester", txtExamSemester.Text.Trim());
                    cmd.Parameters.AddWithValue("@department", txtExamDepartment.Text.Trim());
                    cmd.Parameters.AddWithValue("@courseNumber", Convert.ToInt32(txtExamCourseNumber.Text.Trim()));
                    cmd.Parameters.AddWithValue("@examId", examId);
                    cmd.Parameters.AddWithValue("@examName", txtExamName.Text.Trim());
                    cmd.Parameters.AddWithValue("@examGrade", Convert.ToInt32(txtExamGrade.Text.Trim()));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Exam updated successfully");
                    ExamReset();
                    FillExamDataGridView();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        void FillExamDataGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("ExamSearch", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.Parameters.AddWithValue("@studentId", txtExamStudentId.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@firstName", txtExamFirstName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@lastName", txtExamLastName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@semester", txtExamSemester.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@department", txtExamDepartment.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@courseNumber", txtExamCourseNumber.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@examName", txtExamName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@examGrade", txtExamGrade.Text.Trim());
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvExam.DataSource = dt;
            con.Close();
        }

        private void btnExamReset_Click(object sender, EventArgs e)
        {
            ExamReset();
        }

        void ExamReset()
        {
            txtExamStudentId.Text = txtExamFirstName.Text = txtExamLastName.Text = txtExamSemester.Text = txtExamDepartment.Text 
                = txtExamCourseNumber.Text = txtExamName.Text = txtExamGrade.Text = "";
            btnExamSave.Text = "Add";
            examId = 0;
            txtExamStudentId.Enabled = true;
            txtExamFirstName.Enabled = true;
            txtExamLastName.Enabled = true;
            txtExamSemester.Enabled = true;
            txtExamDepartment.Enabled = true;
            txtExamCourseNumber.Enabled = true;
            btnExamDelete.Enabled = false;
            btnExamSave.Enabled = true;
            PopulateExamListBox("", "");
            FillExamDataGridView();

        }

        private void btnExamSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillExamDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dgvExam_DoubleClick(object sender, EventArgs e)
        {
            if (dgvExam.CurrentRow.Index != -1)
            {
                string studentId = dgvExam.CurrentRow.Cells[0].Value.ToString();
                string semester = dgvExam.CurrentRow.Cells[3].Value.ToString();

                txtExamStudentId.Text = studentId;
                txtExamStudentId.Enabled = false;
                txtExamFirstName.Text = dgvExam.CurrentRow.Cells[1].Value.ToString();
                txtExamFirstName.Enabled = false;
                txtExamLastName.Text = dgvExam.CurrentRow.Cells[2].Value.ToString();
                txtExamLastName.Enabled = false;
                txtExamSemester.Text = semester;
                txtExamDepartment.Text = dgvExam.CurrentRow.Cells[4].Value.ToString();
                txtExamCourseNumber.Text = dgvExam.CurrentRow.Cells[5].Value.ToString();


                PopulateExamListBox(studentId, semester);

                btnExamSave.Text = "Update";
                btnExamSave.Enabled = true;
                btnExamDelete.Enabled = true;
            }
        }

        private void btnExamDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlCommand cmd = new SqlCommand("ExamDelete", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@examId", examId);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Exam deleted successfully");
                ExamReset();
                FillExamDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        void PopulateExamListBox(string studentId, string semester)
        {


            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("ExamListBox", con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.AddWithValue("@studentId", studentId);
                sda.SelectCommand.Parameters.AddWithValue("@semester", semester);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                lstExam.DisplayMember = "exam";
                lstExam.ValueMember = "examId";
                lstExam.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        private void lstExam_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateExamTextFromList();
        }

        private void PopulateExamTextFromList()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("SelectExam", con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.AddWithValue("@examId", lstExam.SelectedValue);
                sda.SelectCommand.Parameters.AddWithValue("@studentId", txtExamStudentId.Text);
                sda.SelectCommand.Parameters.AddWithValue("@semester", txtExamSemester.Text);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                txtExamDepartment.Text = dt.Rows[0][3].ToString();
                txtExamCourseNumber.Text = dt.Rows[0][4].ToString();
                txtExamName.Text = dt.Rows[0][0].ToString();
                txtExamGrade.Text = dt.Rows[0][1].ToString();
                examId = Convert.ToInt32(dt.Rows[0][2].ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        private void menuGpa_Click(object sender, EventArgs e)
        {
            pnlCourses.Visible = false;
            pnlExams.Visible = false;
            pnlGpa.Visible = true;
            pnlRegisteredCourses.Visible = false;
            pnlUsers.Visible = false;

            GpaReset();
        }

        void FillGpaDataGridView()
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("GpaSearch", con);
            sda.SelectCommand.CommandType = CommandType.StoredProcedure;
            sda.SelectCommand.Parameters.AddWithValue("@studentId", txtGpaStudentId.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@firstName", txtGpaFirstName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@lastName", txtGpaLastName.Text.Trim());
            sda.SelectCommand.Parameters.AddWithValue("@semester", txtGpaSemester.Text.Trim());
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dgvGpa.DataSource = dt;
            con.Close();
        }

        private void btnGpaReset_Click(object sender, EventArgs e)
        {
            GpaReset();
        }

        void GpaReset()
        {
            txtGpaStudentId.Text = txtGpaFirstName.Text = txtGpaLastName.Text = txtGpaSemester.Text = "";
            txtGpaStudentId.Enabled = true;
            txtGpaFirstName.Enabled = true;
            txtGpaLastName.Enabled = true;
            txtGpaSemester.Enabled = true;
            PopulateGpaCourseListBox("", "");
            FillGpaDataGridView();

        }
        private void btnGpaSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillGpaDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dgvGpa_DoubleClick(object sender, EventArgs e)
        {
            if (dgvGpa.CurrentRow.Index != -1)
            {
                string studentId = dgvGpa.CurrentRow.Cells[0].Value.ToString();
                string semester = dgvGpa.CurrentRow.Cells[3].Value.ToString();

                txtGpaStudentId.Text = studentId;
                txtGpaStudentId.Enabled = false;
                txtGpaFirstName.Text = dgvGpa.CurrentRow.Cells[1].Value.ToString();
                txtGpaFirstName.Enabled = false;
                txtGpaLastName.Text = dgvGpa.CurrentRow.Cells[2].Value.ToString();
                txtGpaLastName.Enabled = false;
                txtGpaSemester.Text = semester;
                txtGpaSemester.Enabled = false;


                PopulateGpaCourseListBox(studentId, semester);
            }
        }

        private void PopulateGpaCourseListBox(string id, string semester)
        {

      
            string query = "SELECT um.userId, um.fName, um.lName, sg.semester, sg.overallGpa"
                + " FROM userMaster um INNER JOIN studentGpa sg ON um.userId = sg.studentId"
                + " WHERE um.userId = @userId AND sg.semester = @semester";

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                sda.SelectCommand.Parameters.AddWithValue("@userId", id);
                sda.SelectCommand.Parameters.AddWithValue("@semester", semester);


                DataTable dt = new DataTable();
                sda.Fill(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

            try
            {
                query = "SELECT concat(department, ' ', courseNumber) AS course, rc.courseId"
                + " FROM courses c INNER JOIN registeredCourses rc ON c.courseId = rc.courseId"
                + " INNER JOIN userMaster um On rc.studentId = um.userId"
                + " WHERE um.userId = @userId AND rc.semester = @semester";

                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                sda.SelectCommand.Parameters.AddWithValue("@userId", id);
                sda.SelectCommand.Parameters.AddWithValue("@semester", semester);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                lstGpaCourses.DisplayMember = "course";
                lstGpaCourses.ValueMember = "courseId";
                lstGpaCourses.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }

        }

        private void PopulateGpaCoursePanel()
        {
            
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("GpaCourseAvg", con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                sda.SelectCommand.Parameters.AddWithValue("@courseId", lstGpaCourses.SelectedValue);
                sda.SelectCommand.Parameters.AddWithValue("@studentId", txtGpaStudentId.Text.Trim());
                sda.SelectCommand.Parameters.AddWithValue("@semester", txtGpaSemester.Text.Trim());

                DataTable dt = new DataTable();
                sda.Fill(dt);

                txtGpaCourse.Text = dt.Rows[0][0].ToString();
                txtGpaAverage.Text = dt.Rows[0][1].ToString();
                txtGpa.Text = dt.Rows[0][2].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }


            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                SqlDataAdapter sda = new SqlDataAdapter("GpaExamList", con);
                sda.SelectCommand.CommandType = CommandType.StoredProcedure;

                sda.SelectCommand.Parameters.AddWithValue("@courseId", lstGpaCourses.SelectedValue);
                sda.SelectCommand.Parameters.AddWithValue("@studentId", txtGpaStudentId.Text.Trim());
                sda.SelectCommand.Parameters.AddWithValue("@semester", txtGpaSemester.Text.Trim());

                DataTable dt = new DataTable();
                sda.Fill(dt);

                lstGpaExamNamesAndGrades.DisplayMember = "examList";
                lstGpaExamNamesAndGrades.ValueMember = "examId";
                lstGpaExamNamesAndGrades.DataSource = dt;

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
            finally
            {
                con.Close();
            }
        }

        private void lstGpaCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            PopulateGpaCoursePanel();
        }

        private void Admin_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }
                else
                {
                    e.Cancel = true;
                }
            }
            else
            {
                e.Cancel = true;
            }
        }
    }

}
