﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace SIMS
{
    public partial class Login : Form
    {
        SqlConnection con;
        string connectionString;

        public Login()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["SIMS.Properties.Settings.SIMSConnectionString"].ConnectionString;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string query = "SELECT userId, userStatus FROM userMaster " +
                "WHERE userId = @userId AND userPasswd = @userPasswd";

            using (con = new SqlConnection(connectionString))
            using (SqlDataAdapter sda = new SqlDataAdapter(query, con))
            {
                sda.SelectCommand.Parameters.AddWithValue("@userId", txtUserName.Text);
                sda.SelectCommand.Parameters.AddWithValue("@userPasswd", txtPassword.Text);


                DataTable dt = new System.Data.DataTable();
                sda.Fill(dt);
                string userId = dt.Rows[0][0].ToString();
                string userStatus = dt.Rows[0][1].ToString();

                if (dt.Rows.Count == 1)
                {
                    this.Hide();
                    if (userStatus == "student")
                    {
                        Student ss = new Student(userId, userStatus);
                        ss.Show();
                    }
                    else if(userStatus == "admin")
                    {
                        Admin adm = new Admin();
                            adm.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Please Check your Username and Password");
                }
            }
            
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult result = MessageBox.Show("Do you really want to exit?", "Dialog Title", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }
                else
                {
                    e.Cancel = true;
                }
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
}
