﻿namespace SIMS
{
    partial class Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlStudentMain = new System.Windows.Forms.Panel();
            this.txtOverallGpa = new System.Windows.Forms.TextBox();
            this.txtSemester = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lstCourses = new System.Windows.Forms.ListBox();
            this.lblOverallGpa = new System.Windows.Forms.Label();
            this.lblSemester = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.pnlStudentCourse = new System.Windows.Forms.Panel();
            this.lstExamNamesAndGrades = new System.Windows.Forms.ListBox();
            this.txtGpa = new System.Windows.Forms.TextBox();
            this.txtAverage = new System.Windows.Forms.TextBox();
            this.txtCourse = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlStudentMain.SuspendLayout();
            this.pnlStudentCourse.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlStudentMain
            // 
            this.pnlStudentMain.Controls.Add(this.txtOverallGpa);
            this.pnlStudentMain.Controls.Add(this.txtSemester);
            this.pnlStudentMain.Controls.Add(this.txtLastName);
            this.pnlStudentMain.Controls.Add(this.txtFirstName);
            this.pnlStudentMain.Controls.Add(this.lstCourses);
            this.pnlStudentMain.Controls.Add(this.lblOverallGpa);
            this.pnlStudentMain.Controls.Add(this.lblSemester);
            this.pnlStudentMain.Controls.Add(this.lblLastName);
            this.pnlStudentMain.Controls.Add(this.lblFirstName);
            this.pnlStudentMain.Controls.Add(this.pnlStudentCourse);
            this.pnlStudentMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlStudentMain.Location = new System.Drawing.Point(0, 0);
            this.pnlStudentMain.Name = "pnlStudentMain";
            this.pnlStudentMain.Size = new System.Drawing.Size(783, 527);
            this.pnlStudentMain.TabIndex = 0;
            // 
            // txtOverallGpa
            // 
            this.txtOverallGpa.Enabled = false;
            this.txtOverallGpa.Location = new System.Drawing.Point(125, 303);
            this.txtOverallGpa.Name = "txtOverallGpa";
            this.txtOverallGpa.Size = new System.Drawing.Size(183, 20);
            this.txtOverallGpa.TabIndex = 3;
            // 
            // txtSemester
            // 
            this.txtSemester.Enabled = false;
            this.txtSemester.Location = new System.Drawing.Point(125, 114);
            this.txtSemester.Name = "txtSemester";
            this.txtSemester.Size = new System.Drawing.Size(183, 20);
            this.txtSemester.TabIndex = 3;
            // 
            // txtLastName
            // 
            this.txtLastName.Enabled = false;
            this.txtLastName.Location = new System.Drawing.Point(125, 89);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(183, 20);
            this.txtLastName.TabIndex = 3;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Enabled = false;
            this.txtFirstName.Location = new System.Drawing.Point(125, 64);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(183, 20);
            this.txtFirstName.TabIndex = 3;
            // 
            // lstCourses
            // 
            this.lstCourses.FormattingEnabled = true;
            this.lstCourses.Location = new System.Drawing.Point(61, 153);
            this.lstCourses.Name = "lstCourses";
            this.lstCourses.Size = new System.Drawing.Size(247, 134);
            this.lstCourses.TabIndex = 2;
            this.lstCourses.SelectedIndexChanged += new System.EventHandler(this.lstCourses_SelectedIndexChanged);
            // 
            // lblOverallGpa
            // 
            this.lblOverallGpa.AutoSize = true;
            this.lblOverallGpa.Location = new System.Drawing.Point(58, 306);
            this.lblOverallGpa.Name = "lblOverallGpa";
            this.lblOverallGpa.Size = new System.Drawing.Size(68, 13);
            this.lblOverallGpa.TabIndex = 1;
            this.lblOverallGpa.Text = "Overall GPA:";
            // 
            // lblSemester
            // 
            this.lblSemester.AutoSize = true;
            this.lblSemester.Location = new System.Drawing.Point(58, 117);
            this.lblSemester.Name = "lblSemester";
            this.lblSemester.Size = new System.Drawing.Size(54, 13);
            this.lblSemester.TabIndex = 1;
            this.lblSemester.Text = "Semester:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(58, 92);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(58, 64);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 1;
            this.lblFirstName.Text = "First Name:";
            // 
            // pnlStudentCourse
            // 
            this.pnlStudentCourse.Controls.Add(this.lstExamNamesAndGrades);
            this.pnlStudentCourse.Controls.Add(this.txtGpa);
            this.pnlStudentCourse.Controls.Add(this.txtAverage);
            this.pnlStudentCourse.Controls.Add(this.txtCourse);
            this.pnlStudentCourse.Controls.Add(this.label3);
            this.pnlStudentCourse.Controls.Add(this.label2);
            this.pnlStudentCourse.Controls.Add(this.label1);
            this.pnlStudentCourse.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlStudentCourse.Location = new System.Drawing.Point(397, 0);
            this.pnlStudentCourse.Name = "pnlStudentCourse";
            this.pnlStudentCourse.Size = new System.Drawing.Size(386, 527);
            this.pnlStudentCourse.TabIndex = 0;
            // 
            // lstExamNamesAndGrades
            // 
            this.lstExamNamesAndGrades.FormattingEnabled = true;
            this.lstExamNamesAndGrades.Location = new System.Drawing.Point(62, 172);
            this.lstExamNamesAndGrades.Name = "lstExamNamesAndGrades";
            this.lstExamNamesAndGrades.Size = new System.Drawing.Size(220, 147);
            this.lstExamNamesAndGrades.TabIndex = 2;
            // 
            // txtGpa
            // 
            this.txtGpa.Enabled = false;
            this.txtGpa.Location = new System.Drawing.Point(124, 126);
            this.txtGpa.Name = "txtGpa";
            this.txtGpa.Size = new System.Drawing.Size(100, 20);
            this.txtGpa.TabIndex = 1;
            // 
            // txtAverage
            // 
            this.txtAverage.Enabled = false;
            this.txtAverage.Location = new System.Drawing.Point(124, 93);
            this.txtAverage.Name = "txtAverage";
            this.txtAverage.Size = new System.Drawing.Size(100, 20);
            this.txtAverage.TabIndex = 1;
            // 
            // txtCourse
            // 
            this.txtCourse.Enabled = false;
            this.txtCourse.Location = new System.Drawing.Point(124, 64);
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(100, 20);
            this.txtCourse.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "GPA:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Average:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Course:";
            // 
            // Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(783, 527);
            this.Controls.Add(this.pnlStudentMain);
            this.MaximizeBox = false;
            this.Name = "Student";
            this.Text = "Student Information Management System";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Student_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.pnlStudentMain.ResumeLayout(false);
            this.pnlStudentMain.PerformLayout();
            this.pnlStudentCourse.ResumeLayout(false);
            this.pnlStudentCourse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlStudentMain;
        private System.Windows.Forms.Panel pnlStudentCourse;
        private System.Windows.Forms.TextBox txtOverallGpa;
        private System.Windows.Forms.TextBox txtSemester;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.ListBox lstCourses;
        private System.Windows.Forms.Label lblOverallGpa;
        private System.Windows.Forms.Label lblSemester;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.ListBox lstExamNamesAndGrades;
        private System.Windows.Forms.TextBox txtGpa;
        private System.Windows.Forms.TextBox txtAverage;
        private System.Windows.Forms.TextBox txtCourse;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}