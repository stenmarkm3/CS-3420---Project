﻿
Public Class Form1
    Dim SQL As New SQLControl

    Public Sub LoadGrid()
        SQL.ExecQuery("SELECT * From courses;")
        SQL.ExecQuery("SELECT * From exams;")
        SQL.ExecQuery("SELECT * From registeredCourses;")
        If SQL.HasException(True) Then Exit Sub

        dgvData.DataSource = SQL.DBDT
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If SQL.HasConnection = True Then
            MsgBox("Connection Successfull.")
        End If

        LoadGrid()
    End Sub
End Class
