﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class SQLControl
    Private DBCon As New SqlConnection("Server=BEN;Database=SIMS;Trusted_connection=True;")
    Private DBCmd As SqlCommand

    Public Function HasConnection() As Boolean
        Try
            DBCon.Open()

            DBCon.Close()
            Return True
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

    'DB Data
    Public DBDA As SqlDataAdapter
    Public DBDT As DataTable

    'Query parameters
    Public Params As New List(Of SqlParameter)

    'Query statistics
    Public RecordCount As Integer
    Public Exception As String

    'Execute query sub
    Public Sub ExecQuery(Query As String)
        'Reset query stats
        RecordCount = 0
        Exception = ""

        Try
            DBCon.Open()

            'Create DB command
            DBCmd = New SqlCommand(Query, DBCon)

            'Load params into dm commands
            Params.ForEach(Sub(p) DBCmd.Parameters.Add(p))

            'Clear params list
            Params.Clear()

            'execute command and fill dataset
            DBDT = New DataTable
            DBDA = New SqlDataAdapter(DBCmd)
            RecordCount = DBDA.Fill(DBDT)
        Catch ex As Exception

            'Capture errors
            Exception = "ExecQuery Error: " & vbNewLine & ex.Message

        Finally
            'Close connection
            If DBCon.State = ConnectionState.Open Then DBCon.Close()

        End Try
    End Sub

    'Add params
    Public Sub AddParams(Name As String, Value As Object)
        Dim NewParam As New SqlParameter(Name, Value)
        Params.Add(NewParam)
    End Sub

    'Error checking
    Public Function HasException(Optional Report As Boolean = False) As Boolean
        If String.IsNullOrEmpty(Exception) Then Return False
        If Report = True Then MsgBox(Exception, MsgBoxStyle.Critical, "Exception:")
        Return True
    End Function

End Class
